#include "NetworkDelayTime.h"

int networkDelayTime(HashMap<int, Vector<Edge> > &graph, int n, int k) {
	return -2;
} 
