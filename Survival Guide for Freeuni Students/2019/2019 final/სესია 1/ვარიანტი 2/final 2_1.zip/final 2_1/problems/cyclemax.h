#include <string>
#include <Grid.h>

using namespace std;

int removeCycleMax(Grid<int> &g);