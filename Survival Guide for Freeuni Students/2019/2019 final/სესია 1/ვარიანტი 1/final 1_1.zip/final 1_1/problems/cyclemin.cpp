#include "cyclemin.h"


int removeCycleMin(Vector<edgeT *> &g) {
	return -2;
}