/*
 * char_frequencies.cpp
------------ * 
 * This program reads file and outputs the
 * number of occurances for each latin character
 * found in text.
 */ 
#include <iostream>
#include <fstream> // used for file I/O
#include <string>
#include "console.h"
#include "vector.h"
using namespace std;

// Function prototype

const string IN_FILENAME = "input.txt";
const string OUT_FILENAME = "output.txt";
const int ALPHABET_SIZE = 26;

int main() {
	Vector<int> letterCount(ALPHABET_SIZE, 0);

	ifstream inputFile;
	inputFile.open(IN_FILENAME.c_str());

	while (true) {
		char c;
		inputFile.get(c);
		if (inputFile.fail()) {
			break;
		}
		if ('a' <= c && c <= 'z') {
			++letterCount[c - 'a'];
		}
		if ('A' <= c && c <= 'Z') {
			++letterCount[c - 'A'];
		}
	}

	inputFile.close();
	for (int i = 0; i < ALPHABET_SIZE; ++i) {
		cout << "count of " << (char)('A' + i) << " is: ";
		cout << letterCount[i] << endl;
	}

	return 0;
}
