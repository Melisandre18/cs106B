/*
 * write_odds_evens.cpp
------------ * 
 * This program outputs the words read from
 * one file to another file in the following order:
 * First are output the odd position words and then
 * the even ones.
 */ 
#include <iostream>
#include <fstream> // used for file I/O
#include <string>
#include "tokenscanner.h"
#include "vector.h"
using namespace std;

// Function prototype
Vector<string> addWordsFromFile(string filename, TokenScanner scanner);
void printFromVectorStartingFromByStepInto(Vector<string>& vec, int startIndex,
												int step, ofstream& outputStream);

const string IN_FILENAME = "input.txt";
const string OUT_FILENAME = "output.txt";

int main() {
	TokenScanner scanner;
	Vector<string> wordList;

	scanner.ignoreWhitespace();
	
	wordList = addWordsFromFile(IN_FILENAME, scanner);
	
	// Writing to file
	ofstream outputFile;
	outputFile.open(OUT_FILENAME.c_str());

	printFromVectorStartingFromByStepInto(wordList, 0, 2, outputFile);
	printFromVectorStartingFromByStepInto(wordList, 1, 2, outputFile);
	outputFile.close();

	return 0;
}

Vector<string> addWordsFromFile(string filename, TokenScanner scanner) {
	Vector<string> wordList;
	ifstream inputFile;
	inputFile.open(filename.c_str());

	scanner.setInput(inputFile);

	while (scanner.hasMoreTokens()) {
		wordList.add(scanner.nextToken());
	}

	inputFile.close();
	return wordList;
}

void printFromVectorStartingFromByStepInto(Vector<string>& vec, int startIndex, int step,
										   ofstream& outputStream) {
	for (int i = startIndex; i < vec.size(); i += step) {
		outputStream << vec[i];
		if (i + step < vec.size()) {
			outputStream << " ";
		} else {
			outputStream << endl;
		}
	}
}
