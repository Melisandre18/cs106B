/*
 * write_reverse.cpp
------------ * 
 * This program outputs the words read from
 * one file to another file in reverse order.
 */ 
#include <iostream>
#include <fstream> // used for file I/O
#include <string>
#include "tokenscanner.h"
#include "stack.h"
using namespace std;

// Function prototype
Stack<string> pushWordsFromFile(string filename, TokenScanner scanner);
void writeReverseToFile(string filename, Stack<string> wordStack);

const string IN_FILENAME = "input.txt";
const string OUT_FILENAME = "output.txt";

int main() {
	TokenScanner scanner;
	Stack<string> wordStack;

	scanner.ignoreWhitespace();
	
	wordStack = pushWordsFromFile(IN_FILENAME, scanner);
	writeReverseToFile(OUT_FILENAME, wordStack);

	return 0;
}

Stack<string> pushWordsFromFile(string filename, TokenScanner scanner) {
	Stack<string> wordStack;
	ifstream inputFile;
	inputFile.open(filename.c_str());

	scanner.setInput(inputFile);

	while (scanner.hasMoreTokens()) {
		wordStack.push(scanner.nextToken());
	}

	inputFile.close();
	return wordStack;
}

void writeReverseToFile(string filename, Stack<string> wordStack) {
	ofstream outputFile;
	outputFile.open(filename.c_str());

	while (!wordStack.isEmpty()) {
		outputFile << wordStack.pop();
		if (!wordStack.isEmpty()) {
			outputFile << " ";
		} else {
			outputFile << endl;
		}
	}
	outputFile.close();
}