#include <iostream>
#include "console.h"
#include "deque.h"

int main() {
	Deque<double>* deque = new Deque<double>();

	deque->pushFront(2.4);
	deque->pushFront(3);
	deque->pushFront(-1);
	deque->pushFront(0);
	deque->pushFront(0);

	(*deque).pushBack(100);
	(*deque).pushBack(200);
	(*deque).pushBack(-24);
	(*deque).pushBack(56.23);
	(*deque).pushBack(0.0002);

	std::cout << deque->isEmpty() << std::endl;

	deque->pushBack(deque->popFront());
	deque->pushBack(deque->popFront());
	deque->pushBack(deque->popFront());
	deque->pushBack(deque->popFront());

	deque->pushFront(deque->popBack());
	deque->pushFront(deque->popBack());

	while (!deque->isEmpty()) {
		std::cout << deque->popFront() << std::endl;
	}

	delete deque;

	return 0;
}
