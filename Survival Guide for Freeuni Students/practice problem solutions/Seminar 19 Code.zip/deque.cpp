#include "error.h"
#include "deque.h"

template <typename T>
Deque<T>::Deque() {
	head = new Node;
	tail = new Node;

	head -> next = tail;
	head -> prev = NULL;

	tail -> prev = head;
	tail -> next = NULL;
}

template <typename T>
Deque<T>::~Deque() {
	Node* ptr = head;
	while (ptr != NULL) {
		Node* tmp = ptr;
		ptr = ptr -> next;
		delete tmp;
	}
}

template <typename T>
bool Deque<T>::isEmpty() {
	return (head -> next == tail);
}

template <typename T>
void Deque<T>::pushFront(T value) {
	Node* newNode = new Node;
	newNode -> value = value;
	newNode -> next = head -> next;
	newNode -> prev = head;

    head -> next = newNode;

    newNode -> next -> prev = newNode;
}

template <typename T>
void Deque<T>::pushBack(T value) {
	Node* newNode = new Node;
	newNode -> value = value;
	newNode -> next = tail;
	newNode -> prev = tail -> prev;
	
	tail -> prev = newNode;
	
	newNode -> prev -> next = newNode;
}

template <typename T>
T Deque<T>::popFront() {
	if (isEmpty()) {
		error("Attempted to pop empty deque");
	}

	Node* tmp = head -> next;
	head -> next = tmp -> next;
	tmp -> next -> prev = head;

	T result = tmp -> value;

	delete tmp;

	return result;
}

template <typename T>
T Deque<T>::popBack() {
	if (isEmpty()) {
		error("Attempted to pop empty deque");
	}
	
	Node* tmp = tail -> prev;
	tail -> prev = tmp -> prev;
	tmp -> prev -> next = tail;
	
	T result = tmp -> value;
	
	delete tmp;
	
	return result;
}

template class Deque<int>;
template class Deque<double>;
