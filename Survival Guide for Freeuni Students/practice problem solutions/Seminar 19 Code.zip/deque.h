#ifndef DEQUE_H_
#define DEQUE_H_

template <typename T>
class Deque {
public:
	Deque();
	
	~Deque();
	
	bool isEmpty();
	
	void pushFront(T value);
	
	void pushBack(T value);
	
	T popFront();
	
	T popBack();

private:
	struct Node {
		T value;
		Node* next;
		Node* prev;
	};
	Node* head;
	Node* tail;
};

#endif
