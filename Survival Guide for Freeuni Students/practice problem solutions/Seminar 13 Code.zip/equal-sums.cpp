/*
 * equal-sums.cpp
 * ------------
 * Program determines the total number of every
 * subsequences of length 3 which sums up
 * to some K in the sequence of given
 * number of elements.
 */

#include <iostream>
#include "console.h"
#include "simpio.h"
#include "vector.h"
using namespace std;

const int SENTINEL = -1;
const int LEN_MIN_SEQUENCE = 3;

/* Function prototypes */
void consecutiveSums();
int countSubsequences(int sumTo, int numElems);
int countSubsequences(int sumTo, int numElems, Vector<int>& sequence);
bool isCorrectSequence(Vector<int>& sequence, int sumTo);

int main() {
	consecutiveSums();
	return 0;
}

void consecutiveSums() {
	int sumTo = getInteger("Enter the sum value: ");

	int numElems = LEN_MIN_SEQUENCE;
	while (true) {
		numElems = getInteger("Enter number of sequence elements (>=3): ");
		if (numElems >= LEN_MIN_SEQUENCE) {
			break;
		}
		cout << "It has to be longer than 2 elements" << endl;
	}

	int numSequences = countSubsequences(sumTo, numElems);
	cout << "There are total of " << numSequences << endl;
}

int countSubsequences(int sumTo, int numElems) {
	Vector<int> sequence;
	return countSubsequences(sumTo, numElems, sequence);
}

int countSubsequences(int sumTo, int numElems, Vector<int>& sequence) {
	if (sequence.size() == numElems) {
		// cout << sequence.toString() << endl;
		return 1;
	}
	
	int result = 0;

	for (int number = 0; number <= 9; ++number) {
		sequence.add(number);

		if (isCorrectSequence(sequence, sumTo)) {
			result += countSubsequences(sumTo, numElems, sequence);
		}

		sequence.remove(sequence.size() - 1);
	}

	return result;
}

bool isCorrectSequence(Vector<int>& sequence, int sumTo) {
	if (sequence.size() < LEN_MIN_SEQUENCE) {
		return true;
	}

	int newNum = sequence[sequence.size() - 1];
	int lastNum = sequence[sequence.size() - 2];
	int beforeLastNum = sequence[sequence.size() - 3];

	int sum = newNum + lastNum + beforeLastNum;
	
	return sum == sumTo;
}
