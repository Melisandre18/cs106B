/*
 * equal-sums.cpp
 * ------------
 * Program determines the total number of every
 * subsequences of length 3 which sums up
 * to some K in the sequence of given
 * number of elements.
 */

#include <iostream>
#include "console.h"
#include "simpio.h"
#include "map.h"
using namespace std;

/* Function prototypes */
int countTrueSentences(int n, Map<int, int>& storedValues);

int main() {
	int q = getInteger("Enter number of logical operators: ");
	Map<int, int> values;
	cout << countTrueSentences(q, values) << endl;

	return 0;
}

int countTrueSentences(int n, Map<int, int>& storedValues) {
	if (storedValues.containsKey(n)) {
		return storedValues[n];
	}

	// case when there is no OR operator
	int result = 1;

	// case with at least one OR operator
	// loop over the last appearance of OR operator
	for (int i = 1; i <= n; ++i) {
		result += (1 << (2*(n - i) + 1)); // because number of true/false variables are more by 1 to the number of operators
		result += ((1 << i) - 1)*countTrueSentences(n - i, storedValues);
	}
	storedValues[n] = result;
	return result;
}
