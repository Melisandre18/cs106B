/*
 * simple-sorts.cpp
 * ------------
 * Insertion and selection sort demonstration.
 * (with swap counter)
 */

#include <iostream>
#include "console.h"
#include "simpio.h"
#include "vector.h"
#include "random.h"
using namespace std;

const int DEFAULT_SIZE = 20;

/* Function prototypes */
int selectionSortWithCompareCount(Vector<int>& vec);
int insertionSortWithCompareCount(Vector<int>& vec);
void swap(int& a, int& b);
Vector<int> getRandomList(int size = DEFAULT_SIZE);

int main() {
	Vector<int> randomList1 = getRandomList();
	Vector<int> randomList2 = randomList1;

	int ss = selectionSortWithCompareCount(randomList1);
	cout << "It took " << ss << " swaps" << endl;

	int is = insertionSortWithCompareCount(randomList2);
	cout << "It took " << is << " swaps" << endl;

	return 0;
}

int selectionSortWithCompareCount(Vector<int>& vec) {
	int result = 0;
	
	for (int i = 0; i < vec.size(); ++i) {
		int minIndex = i;
		for (int j = i + 1; j < vec.size(); ++j) {
			if (vec[j] < vec[minIndex]) {
				minIndex = j;
			}
			result++;
		}
		swap(vec[i], vec[minIndex]);
	}
	return result;
}

int insertionSortWithCompareCount(Vector<int>& vec) {
	int result = 0;
	
	for (int i = 1; i < vec.size(); ++i) {
		int currentPosition = i;
		
		while (currentPosition > 0) {
			++result;
			if (vec[currentPosition] < vec[currentPosition - 1]) {
				swap(vec[currentPosition], vec[currentPosition - 1]);
				--currentPosition;
			} else {
				break;
			}
		}
	}
	return result;
}

void swap(int& a, int& b) {
	int tmp = a;
	a = b;
	b = tmp;
}

Vector<int> getRandomList(int size) {
	Vector<int> result;

	for (int i = 0; i < size; ++i) {
		result.add(randomInteger(0, 100));
	}

	return result;
}
