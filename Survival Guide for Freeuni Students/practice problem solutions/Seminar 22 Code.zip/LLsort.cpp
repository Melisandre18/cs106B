#ifndef NULL 
#define NULL 0
#endif

#include "LLsort.h"

Node* merge(Node* list1, Node* list2) {
	if (list1 == NULL) {
		return list2;
	}
	
	if (list2 == NULL) {
		return list1;
	}
	
	Node* minNode;
	if (list1 -> val <= list2 -> val) {
		minNode = list1;
		minNode -> next = merge(list1 -> next, list2);
	} else {
		minNode = list2;
		minNode -> next = merge(list1, list2 -> next);
	}
	return minNode;
}

void splitPartFromList(Node*& list1, Node*& list2, int size) {
	Node* midPtr = list1;
	
	while (size > 1) {
		midPtr = midPtr -> next;
		--size;
	}

	list2 = midPtr -> next;
	midPtr -> next = NULL;
}

void sortListOfSize(Node*& list, int size) {
	if (list -> next == NULL) {
		return;
	}

	Node* list2;
	splitPartFromList(list, list2, size/2);
	sortListOfSize(list, size/2);
	sortListOfSize(list2, size - size/2);

	list = merge(list, list2);
}

int getLength(Node* list) {
	int size = 0;
	while (list != NULL) {
		++size;
		list = list -> next;
	}
	return size;
}

void sortList(Node*& list) {
	if (list == NULL) {
		return;
	}
	
	int len = getLength(list);
	sortListOfSize(list, len);
}
