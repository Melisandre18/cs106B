#ifndef LL_SORT_
#define LL_SORT_

struct Node {
	int val;
	Node* next;
};

void sortList(Node*& list);

#endif
