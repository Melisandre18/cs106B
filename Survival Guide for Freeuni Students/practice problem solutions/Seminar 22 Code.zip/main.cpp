#include <iostream>
#include "console.h"
#include "LLsort.h"

int main() {
	Node* n5 = new Node;
	n5->val = -123;
	n5->next = NULL;

	Node* n4 = new Node;
	n4->val = 4;
	n4->next = n5;

	Node* n3 = new Node;
	n3->val = 123;
	n3->next = n4;

	Node* n2 = new Node;
	n2->val = 42;
	n2->next = n3;

	Node* n1 = new Node;
	n1->val = 0;
	n1->next = n2;

	sortList(n1);

	for (Node* curr = n1; curr != NULL; curr = curr->next) {
		std::cout << curr->val << std::endl;
	}

	Node* curr = n1;
	while (curr != NULL) {
		Node *tmp = curr;
		curr = curr->next;
		delete tmp;
	}
	
	return 0;
}
