#ifndef LL_STRING_H_
#define LL_STRING_H_

#include <string>

using namespace std;

class LLstring {
public:
	LLstring(string other = "");

	LLstring(const LLstring& other);

	~LLstring();

	string toString();

	LLstring operator+ (LLstring& other);

private:
	struct Node {
		char val;
		Node* next;
	};
	Node* head;
	Node* fullCopy(Node* src, Node* tail);
};

#endif
