#include <iostream>
#include "console.h"
#include "LLstring.h"

int main() {
	LLstring lstr1("another");
	std::cout << lstr1.toString() << std::endl;

	LLstring lstrCopy(lstr1);
	std::cout << lstrCopy.toString() << std::endl;

	LLstring lstr2(" one");
	std::cout << (lstr1 + lstr2).toString() << std::endl;

	LLstring sum = lstr1 + lstr2;
	std::cout << sum.toString() << std::endl;

	return 0;
}
