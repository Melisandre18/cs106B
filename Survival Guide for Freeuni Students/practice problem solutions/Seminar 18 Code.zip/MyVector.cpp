#include "MyVector.h"
#include "error.h"

MyVector::MyVector(int capacity) {
	currentSize = 0;
	data.resize(capacity);
}

double MyVector::getAt(int index) {
	return data.getAt(index);
}

void MyVector::setAt(int index, double value) {
	data.setAt(index, value);
}

int MyVector::size() {
	return currentSize;
}

void MyVector::add(double value) {
	if (currentSize >= data.size()) {
		data.resize(2*data.size() + 1);
	}

	data.setAt(currentSize, value);
	++currentSize;
}

double MyVector::popLast() {
	if (currentSize == 0) {
		error("no more elements");
	}

	double result = data.getAt(currentSize - 1);
	--currentSize;
	
	if (currentSize*4 < data.size()) {
		data.resize(data.size()/2);
	}
	
	return result;
}

std::string MyVector::toString() {
	return data.toString();
}
