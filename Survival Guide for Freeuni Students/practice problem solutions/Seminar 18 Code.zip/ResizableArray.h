#ifndef RESIZABLE_ARRAY_H_
#define RESIZABLE_ARRAY_H_

#include <string>

class ResizableArray {
public:
	ResizableArray(int size = 10);

	~ResizableArray();

	void resize(int newSize);

	double getAt(int index);

	void setAt(int index, double value);

	int size();

	std::string toString();

private:
	int currentSize;
	double* data;
};

#endif
