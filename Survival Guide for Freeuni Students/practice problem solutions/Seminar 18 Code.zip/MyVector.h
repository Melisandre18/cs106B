#ifndef MY_VECTOR_H_
#define MY_VECTOR_H_

#include "ResizableArray.h"
#include <string>

static const int DEFAULT_SIZE = 10;

class MyVector {
public:
	MyVector(int capacity = DEFAULT_SIZE);
	
	double getAt(int index);
	
	void setAt(int index, double value);
	
	int size();
	
	void add(double value);
	
	double popLast();

	std::string toString();

private:
	
	int currentSize;
    ResizableArray data;
};

#endif
