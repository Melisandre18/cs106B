#include <iostream>
#include "console.h"
#include "MyVector.h"

int main() {
	MyVector vec;
	vec.add(5.6);
	vec.add(2);
	vec.add(23);
	vec.add(-2);
	vec.add(-3.5);
	vec.add(0);
	vec.add(5.6);
	vec.add(2);
	vec.add(23);
	vec.add(-2);
	vec.add(-3.5);
	vec.add(0);
	vec.add(5.6);
	vec.add(2);
	vec.add(23);
	vec.add(-2);
	vec.add(-3.5);
	vec.add(0);

	std::cout << vec.toString() << std::endl;

	return 0;
}
