#include "error.h"
#include "ResizableArray.h"
#include "strlib.h"

ResizableArray::ResizableArray(int size) {
	currentSize = size;
	data = new double[currentSize];
	
	for (int i = 0; i < currentSize; ++i) {
		data[i] = 0.0;
	}
}

ResizableArray::~ResizableArray() {
	delete[] data;
}

int ResizableArray::size() {
	return currentSize;
}

double ResizableArray::getAt(int index) {
	if (0 <= index && index < currentSize) {
		return data[index]; // return *(data + index);
	} else {
		error("index out of bounds");
	}
}

void ResizableArray::setAt(int index, double value) {
	if (0 <= index && index < currentSize) {
		data[index] = value; // *(data + index) = value;
	} else {
		error("index out of bounds");
	}
}

void ResizableArray::resize(int newSize) {
	double* tmpData = new double[newSize];
	
	for (int i = 0; i < currentSize && i < newSize; ++i) {
		tmpData[i] = data[i];
	}

	for (int i = currentSize; i < newSize; ++i) {
		tmpData[i] = 0.0;
	}

	delete[] data;
	data = tmpData;

	currentSize = newSize;
}

std::string ResizableArray::toString() {
	std::string result = "";
	for (int i = 0; i < this->currentSize; ++i) {
		result += realToString(data[i]);
		result += " ";
	}
	return result;
}
