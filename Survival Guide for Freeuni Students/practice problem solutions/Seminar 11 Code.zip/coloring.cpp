/*
 * coloring.cpp
 * ------------
 * This program tries to find whether the
 * given graph can be colored using the
 * specified amount of colors so that
 * neighboring vertices will be of distinct
 * color.
 */

#include <iostream>
#include "console.h"
#include "simpio.h"
#include "strlib.h"
#include "grid.h"
#include "vector.h"
using namespace std;

const int NUM_ROWS = 4;
const int NUM_COLS = 4;

// Function prototypes
bool canBeColored(Grid<bool>& graph,
				  int colorCount,
				  Vector<int>& coloringResult);
bool isColoringValid(Grid<bool>& graph,
					 Vector<int>& coloringResult,
					 int newColor);
Grid<bool> getTestGraph();
void printBoard(Grid<bool>& board);

int main() {
	// Initialize test grid for demo purposes
	Grid<bool> graph = getTestGraph();
	printBoard(graph);

	Vector<int> coloringResult;
	
	int k = 1;
	while (true) {
		bool canColor = canBeColored(graph, k, coloringResult);

		if (canColor) {
			cout << "Can be colored using " << k << " colors." << endl;
			cout << coloringResult.toString() << endl;
			break;
		}

		++k;
	}

	return 0;
}

bool canBeColored(Grid<bool>& graph,
				  int colorCount,
				  Vector<int>& coloringResult) {
	if (coloringResult.size() == graph.numCols()) {
		return true;
	}

	for (int newColor = 0; newColor < colorCount; ++newColor) {
		if (isColoringValid(graph, coloringResult, newColor)) {
			coloringResult.add(newColor);
			if (canBeColored(graph, colorCount, coloringResult)) {
				return true;
			}
			coloringResult.remove(coloringResult.size() - 1);
		}
	}

	return false;
}

bool isColoringValid(Grid<bool>& graph,
					 Vector<int>& coloringResult,
					 int newColor) {
	int newVertex = coloringResult.size();
	for (int vertex = 0; vertex < newVertex; ++vertex) {
		if (graph[vertex][newVertex] && coloringResult[vertex] == newColor) {
			return false;
		}
	}
	return true;
}

Grid<bool> getTestGraph() {
	Grid<bool> testGrid(NUM_ROWS, NUM_COLS);

	// 0 <-> 2
	testGrid[0][2] = true;
	testGrid[2][0] = true;

	// 2 <-> 1
	testGrid[2][1] = true;
	testGrid[1][2] = true;

	// 1 <-> 3
	testGrid[1][3] = true;
	testGrid[3][1] = true;

	// 3 <-> 0
	testGrid[3][0] = true;
	testGrid[0][3] = true;

	return testGrid;
}

void printBoard(Grid<bool>& board) {
	cout << "   ";
	for (int i = 0; i < board.numCols(); ++i) {
		cout << i << " ";
	}
	cout << endl;

	for (int i = 0; i < board.numRows(); ++i) {
		cout << i << "| ";
		for (int j = 0; j < board.numCols(); ++j) {
			if (board[i][j]) {
				cout << "X ";
			} else {
				cout << "_ ";
			}
		}
		cout << endl;
	}
}
