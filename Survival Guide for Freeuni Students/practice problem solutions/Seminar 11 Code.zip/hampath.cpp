/*
 * hampath.cpp
 * ------------
 * This program tries to find hamilton path
 * in the given graph.
 */

#include <iostream>
#include "console.h"
#include "simpio.h"
#include "strlib.h"
#include "grid.h"
#include "vector.h"
#include "set.h"
using namespace std;

const int NUM_ROWS = 4;
const int NUM_COLS = 4;

// Function prototypes
bool hasHamiltonCycle(Grid<bool>& graph, Vector<int>& resultCycle);
bool hasHamiltonCycleStartingFrom(Grid<bool>& graph,
								  Vector<int>& chosen,
								  Set<int>& chosenSet);
bool isHamiltonCycle(Grid<bool>& graph, Vector<int> sequence);
Grid<bool> getTestGraph();
void printBoard(Grid<bool>& board);

int main() {
	// Initialize test grid for demo purposes
	Grid<bool> graph = getTestGraph();
	printBoard(graph);

	Vector<int> resultCycle;
	bool hasHamPath = hasHamiltonCycle(graph, resultCycle);
	
	if (hasHamPath) {
		cout << "Has Hamilton Path: " << resultCycle.toString() << endl;
	} else {
		cout << "Doesn't have Hamilton Path" << endl;
	}

	return 0;
}

bool hasHamiltonCycle(Grid<bool>& graph, Vector<int>& resultCycle) {
	Set<int> emptySet;
	resultCycle.clear();
	return hasHamiltonCycleStartingFrom(graph, resultCycle, emptySet);
}

bool hasHamiltonCycleStartingFrom(Grid<bool>& graph,
								  Vector<int>& chosen,
								  Set<int>& chosenSet) {
	if (chosen.size() == graph.numCols()) {
		return isHamiltonCycle(graph, chosen);
	}

	for (int newVertex = 0; newVertex < graph.numCols(); ++newVertex) {
		if (!chosenSet.contains(newVertex)) {
			chosen.add(newVertex);
			chosenSet.add(newVertex);
			if (hasHamiltonCycleStartingFrom(graph, chosen, chosenSet)) {
				return true;
			}
			chosen.remove(chosen.size() - 1);
			chosenSet.remove(newVertex);
		}
	}
	return false;
}

bool isHamiltonCycle(Grid<bool>& graph, Vector<int> sequence) {
	for (int i = 0; i < sequence.size(); ++i) {
		int v1 = sequence[i];
		int v2 = sequence[(i + 1) % sequence.size()];
		if (!graph[v1][v2]) {
			return false;
		}
	}
	return true;
}

Grid<bool> getTestGraph() {
	Grid<bool> testGrid(NUM_ROWS, NUM_COLS);

	// 0 <-> 2
	testGrid[0][2] = true;
	testGrid[2][0] = true;

	// 2 <-> 1
	testGrid[2][1] = true;
	testGrid[1][2] = true;

	// 1 <-> 3
	testGrid[1][3] = true;
	testGrid[3][1] = true;

	// 3 <-> 0
	testGrid[3][0] = true;
	testGrid[0][3] = true;

	return testGrid;
}

void printBoard(Grid<bool>& board) {
	cout << "   ";
	for (int i = 0; i < board.numCols(); ++i) {
		cout << i << " ";
	}
	cout << endl;

	for (int i = 0; i < board.numRows(); ++i) {
		cout << i << "| ";
		for (int j = 0; j < board.numCols(); ++j) {
			if (board[i][j]) {
				cout << "X ";
			} else {
				cout << "_ ";
			}
		}
		cout << endl;
	}
}
