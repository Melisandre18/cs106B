/*
 * money_compose.cpp
------------ * 
 * Finds whether the specified value
 * can be composed from the available
 * money.
 */
#include <iostream>
#include "console.h"
#include "simpio.h"
#include "strlib.h"
#include "vector.h"
using namespace std;

const int SENTINEL = -1;

// Function prototypes
bool canComposeWith(int value, Vector<int>& units);
Vector<int> getUnitsFromUser();

int main() {
	int value = getInteger("Enter desired value: ");

	Vector<int> units = getUnitsFromUser();
	
	bool canBeComposed = canComposeWith(value, units); 
	
	if (canBeComposed) {
		cout << "Can be composed" << endl;
	} else {
		cout << "Cannot be composed" << endl;
	}

	return 0;
}

bool canComposeWith(int value, Vector<int>& units) {
	if (0 == value) {
		return true;
	}
	
	if ( 0 > value) {
		return false;
	}

	bool result = false;
	for (int i = 0; i < units.size(); ++i) {
		result = result || canComposeWith(value - units[i], units);
	}
	return result;
}

Vector<int> getUnitsFromUser() {
	Vector<int> result;

	while (true) {
		int val = getInteger("Enter unit (or " + integerToString(SENTINEL) + " to stop): ");
		if (val == SENTINEL) {
			break;
		}
		result += val;
	}

	return result;
}
