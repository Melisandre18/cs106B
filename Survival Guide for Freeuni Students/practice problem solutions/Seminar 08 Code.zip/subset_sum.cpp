/*
 * subset_sum.cpp
------------ * 
 * Finds whether any subset of the given
 * list can sum up to the specified value.
 */
#include <iostream>
#include "console.h"
#include "simpio.h"
#include "strlib.h"
#include "vector.h"
using namespace std;

const int SENTINEL = -1;

// Function prototypes
bool subsetSum(int target, Vector<int>& set, int startIndex = 0);
Vector<int> getNumbersFromUser();

int main() {
	int sum = getInteger("Enter sum value: ");

	Vector<int> numbers = getNumbersFromUser();
	
	bool canBeComposed = subsetSum(sum, numbers); 
	
	if (canBeComposed) {
		cout << "Can be summed up to it" << endl;
	} else {
		cout << "Cannot be summed up to it" << endl;
	}

	return 0;
}

bool subsetSum(int target, Vector<int>& set, int startIndex) {
	if (0 == target) {
		return true;
	}
	
	if (startIndex == set.size()) {
		return false;
	}
	
	return (subsetSum(target - set[startIndex], set, startIndex + 1) || subsetSum(target, set, startIndex + 1));
}

Vector<int> getNumbersFromUser() {
	Vector<int> result;

	while (true) {
		int val = getInteger("Enter number (or " + integerToString(SENTINEL) + " to stop): ");
		if (val == SENTINEL) {
			break;
		}
		result += val;
	}

	return result;
}
