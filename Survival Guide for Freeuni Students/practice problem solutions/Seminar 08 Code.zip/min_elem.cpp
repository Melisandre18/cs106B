/*
 * min_elem.cpp
------------ * 
 * Finds minimal element of the given
 * list without using while loop.
 */
#include <iostream>
#include "console.h"
#include "simpio.h"
#include "strlib.h"
#include "vector.h"
using namespace std;

const int SENTINEL = -1;

// Function prototypes
int findMin(Vector<int>& vec, int startIndex = 0);
Vector<int> getVectorFromUser();

int main() {
	Vector<int> numbers = getVectorFromUser();

	cout << "Min = " << findMin(numbers) << endl;

	return 0;
}

int findMin(Vector<int>& vec, int startIndex) {
	if (startIndex == vec.size() - 1) {
		return vec[startIndex];
	}
	
	return min(vec[startIndex], findMin(vec, startIndex + 1));
}

Vector<int> getVectorFromUser() {
	Vector<int> result;

	while (true) {
		int val = getInteger("Enter integer (or " + integerToString(SENTINEL) + " to stop): ");
		if (val == SENTINEL) {
			break;
		}
		result += val;
	}

	return result;
}
