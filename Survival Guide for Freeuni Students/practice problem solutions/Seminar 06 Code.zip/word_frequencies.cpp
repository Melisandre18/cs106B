/*
 * word_frequencies.cpp
------------ * 
 * This program reads file and outputs the
 * number of occurances for each word
 * found in the text file.
 */ 
#include <iostream>
#include <fstream> // used for file I/O
#include <string>
#include "console.h"
#include "tokenscanner.h"
#include "map.h"
using namespace std;

const string IN_FILENAME = "input.txt";
const string OUT_FILENAME = "output.txt";

int main() {
	ifstream inputFile;
	inputFile.open(IN_FILENAME.c_str());

	TokenScanner scanner(inputFile);
	scanner.ignoreWhitespace();

	Map<string, int> wordCount;

	while (scanner.hasMoreTokens()) {
		string nextWord = scanner.nextToken();
		if (wordCount.containsKey(nextWord)) {
			++wordCount[nextWord];
		} else {
			wordCount[nextWord] = 1;
		}
	}

	inputFile.close();

	foreach (string word in wordCount) {
		cout << word << " - " << wordCount[word] << endl;
	}

	return 0;
}
