/*
 * set_strings.cpp
------------ * 
 * Program outputs all common characters from
 * two strings, also the characters absent from
 * the first string and vice-versa.
 */
#include <iostream>
#include <string>
#include "console.h"
#include "simpio.h"
#include "set.h"
using namespace std;

// Function prototypes
Set<char> stringToSet(const string& s);
void printCharSet(Set<char>& set);

int main() {
	string s1 = getLine("Enter first string: ");
	string s2 = getLine("Enter second string: ");

	Set<char> set1 = stringToSet(s1);
	Set<char> set2 = stringToSet(s2);
	
	Set<char> intersection = set1 * set2;
	printCharSet(intersection);

	Set<char> difference1 = set1 - set2;
	printCharSet(difference1);

	Set<char> difference2 = set2 - set1;
	printCharSet(difference2);

	return 0;
}

Set<char> stringToSet(const string& s) {
	Set<char> result;
	for (int i = 0; i < s.length(); ++i) {
		result.insert(s[i]);
	}
	return result;
}

void printCharSet(Set<char>& set) {
	foreach(char c in set) {
		cout << c;
	}
	cout << endl;
}
