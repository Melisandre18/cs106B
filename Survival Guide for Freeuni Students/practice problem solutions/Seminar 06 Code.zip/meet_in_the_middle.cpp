/*
 * meet_in_the_middle.cpp
------------ * 
 * Given two strings, the program determines
 * whether any of these strings can become
 * another string by swapping at most 4 characters.
 *
 * Problem is solved using meet in the middle
 * principle.
 */
#include <iostream>
#include <string>
#include "console.h"
#include "simpio.h"
#include "set.h"
using namespace std;

// Function prototypes
void extendSetByN(Set<string>& set, int n);
void extendSet(Set<string>& set);
string swapCharsAtIndex(string str, int idx);

int main() {
	string s1 = getLine("Enter first string: ");
	string s2 = getLine("Enter second string: ");

	Set<string> reachedFromS1;
	reachedFromS1.insert(s1);
	extendSetByN(reachedFromS1, 2);

	Set<string> reachedFromS2;
	reachedFromS2.insert(s2);
	extendSetByN(reachedFromS2, 2);

	if ((reachedFromS1 * reachedFromS2).isEmpty()) {
		cout << "Cannot be reached" << endl;
	} else {
		cout << "Can be reached" << endl;
	}
	return 0;
}

void extendSetByN(Set<string>& set, int n) {
	for (int i = 0; i < n; ++i) {
		extendSet(set);
	}
}

void extendSet(Set<string>& set) {
	Set<string> newWords;
	foreach (string word in set) {
		for (int i = 0; i < word.length() - 1; ++i) {
			newWords.insert(swapCharsAtIndex(word, i));
		}
	}
	set += newWords;
}

string swapCharsAtIndex(string str, int idx) {
	string result = str;
	result[idx] = str[idx + 1];
	result[idx + 1] = str[idx];
	return result;
}
