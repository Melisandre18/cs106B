/*
 * min-max-average.cpp
------------ * 
 * This program outputs the minimum, maximum and the average
 * value based on the inputs supplied by the client.
 */ 
#include <iostream>
#include "console.h"
#include "simpio.h"
using namespace std;

const int SENTINEL = -1;

/* Convenience structure for storing the result */
struct statsT {
	int min;
	int max;
	double avg;
};

// Function prototype
statsT getSequenceStats(int sentinel);

int main() {
	statsT ans = getSequenceStats(SENTINEL);
	cout << "min = " << ans.min << endl;
	cout << "max = " << ans.max << endl;
	cout << "avg = " << ans.avg << endl;
	
	return 0;
}

statsT getSequenceStats(int sentinel) {
	int count = 0;
	int sum = 0;
	
	statsT result;
	result.min = INT_MAX;
	result.max = INT_MIN;
	
	while (true) {
		cout << "Enter next integer (or " << SENTINEL << " to terminate): ";

		int input = getInteger();
		if (input == SENTINEL) {
			break;
		}
		if (input > result.max) {
			result.max = input;
		}
		if (input < result.min) {
			result.min = input;
		}
		sum += input;
		count += 1;
	}
	result.avg = double(sum)/count;
	return result;
}
