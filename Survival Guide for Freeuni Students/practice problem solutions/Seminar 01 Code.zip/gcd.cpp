/*
 * gcd.cpp
------------ * 
 * This program recursively finds GCD of two numbers
 * using Euclid's algorithm.
 */ 
#include <iostream>
#include "console.h"
#include "simpio.h"
using namespace std;

// Function prototype
int gcd(int p, int q);
int getInputNumber();

int main() {
	cout << "Enter two positive integers" << endl;
	
	int x = getInputNumber();
	int y = getInputNumber();

	int g = gcd(x, y);
	cout << "gcd is: " << g << endl;
	
	return 0;
}

int getInputNumber() {
	int number = getInteger();
	while (number <= 0) {
        cout << "Please make sure the integer is positive" << endl;
        number = getInteger();
    }
	return number;
}

/* Euclid's algorithm */
int gcd(int a, int b) {
	if (b == 0) {
		return a;
	}
	return gcd(b, a % b);
}
