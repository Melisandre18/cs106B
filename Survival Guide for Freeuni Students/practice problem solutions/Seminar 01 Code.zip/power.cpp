/*
 * power.cpp
------------ * 
 * This program recursively finds whether the number
 * is a power of 2 or not.
 */ 
#include <iostream>
#include "console.h"
#include "simpio.h"
using namespace std;

// Function prototype
bool isPowerOfTwo(int n);

int main() {
	int number = getInteger("Enter number: ");
	int isPower = isPowerOfTwo(number);
	
	// Printing result
	cout << number << " is ";
	if (!isPower) {
		cout << "not ";
	}
	cout << "power of two" << endl;
	
	return 0;
}

bool isPowerOfTwo(int n) {
	if (n % 2 == 1) {
		return n == 1;
	}

	return isPowerOfTwo(n / 2);
}
