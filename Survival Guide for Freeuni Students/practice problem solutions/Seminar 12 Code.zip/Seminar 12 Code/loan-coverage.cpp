/*
 * loan-coverage.cpp
 * ------------
 * Various solutions to loan based problems.
 */

#include <iostream>
#include "console.h"
#include "simpio.h"
using namespace std;

// Function prototypes
double dept(double start, double p, double pay, int n);
double pay(double start, double p, int n, double min, double max);

int main() {
	double loanAmount = getReal("Enter loan amount: ");
	double p = getReal("Enter percentage (0.0-1.0 range): ");
	double monthlyPayment = getReal("Enter amount for monthly payment: ");
	int numMonths = getInteger("Enter number of months to cover: ");

	double remaining = dept(loanAmount, p, monthlyPayment, numMonths);
	cout << "Remaining amount to cover after ";
	cout << numMonths << " month(s) is " << remaining << endl;

	double optimalPay = pay(loanAmount, p, numMonths, 0.0, 2*loanAmount);
	cout << "\nYou should pay " << optimalPay << " per month, to ";
	cout << "cover your dept in " << numMonths << " months" << endl;

	return 0;
}

double dept(double start, double p, double pay, int n) {
	if (0 == n) {
		return start;
	}

	return dept(start, p, pay, n - 1)*(1.0 + p) - pay;
}

const double eps = 0.01;

double pay(double start, double p, int n, double min, double max) {	
	if (max - min <= eps) {
		return max;
	}

	double mid = (min + max)/2.0;

	if (dept(start, p, mid, n) > 0) {
		return pay(start, p, n, mid, max);
	} else {
		return pay(start, p, n, min, mid);
	}
}
