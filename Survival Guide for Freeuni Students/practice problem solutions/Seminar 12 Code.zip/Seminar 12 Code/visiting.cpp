/*
 * visiting.cpp
 * ------------
 * This program tries to find the cheapest
 * route to see all cities, each only one
 * time.
 */

#include <iostream>
#include "console.h"
#include "simpio.h"
#include "strlib.h"
#include "grid.h"
#include "vector.h"
#include "set.h"
using namespace std;

const int NUM_ROWS = 4;
const int NUM_COLS = 4;

// Function prototypes
int minValueTravel(Grid<int>& costs, Vector<int>& cities, Set<int>& visited);
Grid<int> getTestGraph();
void printBoard(Grid<int>& board);

int main() {
	// Initialize test grid for demo purposes
	Grid<int> graph = getTestGraph();
	printBoard(graph);
	
	Vector<int> cities;
	Set<int> visited;
	int minCost = minValueTravel(graph, cities, visited);

	cout << "Minimal cost for the unique route: " << minCost << endl;

	return 0;
}

int minValueTravel(Grid<int>& costs, Vector<int>& cities, Set<int>& visited) {
	if (cities.size() == costs.numCols()) {
		int cost = 0;
		for (int i = 0; i < cities.size(); ++i) {
			int currCity = cities[i];
			int nextCity = cities[(i + 1) % cities.size()];
			cost += costs[currCity][nextCity];
		}
		return cost;
	}

	int minCost = INT_MAX;
	for (int city = 0; city < costs.numCols(); ++city) {
		if (!visited.contains(city)) {
			cities.add(city);
			visited.add(city);
			int currentCost = minValueTravel(costs, cities, visited);
			if (currentCost < minCost) {
				minCost = currentCost;
			}
			cities.remove(cities.size() - 1);
			visited.remove(city);
		}
	}
	return minCost;
}

Grid<int> getTestGraph() {
	Grid<int> testGrid(NUM_ROWS, NUM_COLS);

	// 0 <-> 2
	testGrid[0][2] = 3;
	testGrid[2][0] = 3;

	// 2 <-> 1
	testGrid[2][1] = 5;
	testGrid[1][2] = 5;

	// 1 <-> 3
	testGrid[1][3] = 4;
	testGrid[3][1] = 4;

	// 3 <-> 0
	testGrid[3][0] = 7;
	testGrid[0][3] = 7;

	return testGrid;
}

void printBoard(Grid<int>& board) {
	cout << "   ";
	for (int i = 0; i < board.numCols(); ++i) {
		cout << i << " ";
	}
	cout << endl;

	for (int i = 0; i < board.numRows(); ++i) {
		cout << i << "| ";
		for (int j = 0; j < board.numCols(); ++j) {
			cout << board[i][j] << " ";
		}
		cout << endl;
	}
}
