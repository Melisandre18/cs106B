/*
 * knapsack.cpp
 * ------------
 * Solution to the knapsack filling problem.
 */

#include <iostream>
#include "console.h"
#include "vector.h"
#include "simpio.h"

using namespace std;

// item struct
struct itemT {
	int weight;
	int value;
};

// function prototypes
int fillKnapsack(Vector<itemT> &items, int targetWeight);
int fillKnapsack(Vector<itemT> &items, int weight, int score);

int main() {
	// solution: 44
	int values[] = {12, 10, 8, 11, 14, 7, 9};
	int weights[] = {4, 6, 5, 7, 3, 1, 6};
	int targetWeight = 18;

	// solution: 67
	//int values[] = {5, 20, 3, 50, 5, 4, 15, 12, 6, 7};
	//int weights[] = {6, 15, 11, 12, 6, 11, 13, 7, 17, 13};
	//int targetWeight = 25;

	// solution: 7
	//int values[] = {3, 4, 5, 6};
	//int weights[] = {2, 3, 4, 5};
	//int targetWeight = 5;

	int numItems = sizeof(values) / sizeof(int);

	Vector<itemT> testItems;

	for (int i=0; i < numItems; ++i) {
		itemT item;
		item.value = values[i];
		item.weight = weights[i];
		testItems.add(item);
	}

	cout << "Best solution has a best score of: "
		<< fillKnapsack(testItems, targetWeight) << endl;
	return 0;
}

int fillKnapsack(Vector<itemT> &items, int targetWeight) {
	return fillKnapsack(items, targetWeight, 0);
}

int fillKnapsack(Vector<itemT> &items, int weight, int bestScore) {
	if (weight < 0) {
		return 0; // we tried too much weight!
	}
	int localBestScore = bestScore;
	int itemSize = items.size();
	for (int i = 0; i < itemSize; ++i) {
		itemT originalItem = items[i];
		int currValue = bestScore + originalItem.value;
		int currWeight = weight - originalItem.weight;
		// remove object for recursion
		items.remove(i);
		currValue = fillKnapsack(items, currWeight, currValue);
		if (localBestScore < currValue) {
			localBestScore = currValue;
		}
		// replace
		items.insert(i, originalItem);
	}
	return localBestScore;
}
