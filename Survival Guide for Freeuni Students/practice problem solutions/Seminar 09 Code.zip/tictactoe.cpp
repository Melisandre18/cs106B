/*
 * tictactoe.cpp
 * ------------
 * Solutions Tic-Tac-Toe problems. See
 * problem handout for details.
 */

#include <iostream>
#include "console.h"
#include "simpio.h"
#include "strlib.h"
#include "grid.h"
using namespace std;

enum position {
	cross = 1,   // X
	neither = 0,
	nought = -1  // O
};

struct boardT {
	Grid<position> grid;
	position currentPlayer;
};

const int TTT_ROWS = 3;
const int TTT_COLS = 3;

// Function prototypes
bool isGameOver(boardT& board, position& gameResult);
bool doesPlayerWin(boardT& board, position player);
position gameFinalResult(boardT& board);
Grid<position> getTestGrid();
void printBoard(Grid<position>& board);

int main() {
	// Initialize test grid for demo purposes
	Grid<position> grid = getTestGrid();
	printBoard(grid);

	// Initialize grid
	boardT board;
	board.currentPlayer = nought;
	board.grid = grid;
	
	position winner = gameFinalResult(board);

	if (winner == cross) {
		cout << "\nX should win if played correctly" << endl;
	} else if (winner == nought) {
		cout << "\nO should win if played correctly" << endl;
	} else {
		cout << "\nTie if played correctly" << endl;
	}

	return 0;
}

bool isGameOver(boardT& board, position& gameResult) {
	// Check whether the 'X' player has won
	if (doesPlayerWin(board, cross)) {
		gameResult = cross;
		return true;
	}

	// Check whether the 'O' player has won
	if (doesPlayerWin(board, nought)) {
		gameResult = nought;
		return true;
	}

	// Check if the board contains any free cell
	// if it does, it means the game is still on
	for (int i = 0; i < board.grid.numRows(); ++i) {
		for (int j = 0; j < board.grid.numCols(); ++j) {
			if (board.grid[i][j] == neither) {
				return false;
			}
		}
	}

	// If the first or second player hasn't won
	// and there is no free movies left either,
	// it means the game is a tie
	gameResult = neither;
	return true;
}

bool doesPlayerWin(boardT& board, position player) {
	// Checking whether the row or a column is full
	// given the player sign
	for (int i = 0; i < board.grid.numRows(); ++i) {
		bool isRowFull = true;
		bool isColumnFull = true;
		
		for (int j = 0; j < board.grid.numCols(); ++j) {
			if (board.grid[i][j] != player) {
				isRowFull = false;
			}
			if (board.grid[j][i] != player) {
				isColumnFull = false;
			}
		}
		// if either row or a column is full,
		// the player has won
		if (isRowFull || isColumnFull) {
			return true;
		}
	}

	// Check the first diagonal
	if (board.grid[0][0] == player
		&& board.grid[1][1] == player
		&& board.grid[2][2] == player) {
			return true;
	}
	
	// Check the second diagonal
	if (board.grid[0][2] == player
		&& board.grid[1][1] == player
		&& board.grid[2][0] == player) {
			return true;
	}
	
	return false;
}

position gameFinalResult(boardT& board) {
	// base case: if the game is over, return the winner
	position gameResult;
	if (isGameOver(board, gameResult)) {
		return gameResult;
	}

	// choose the next player based on the current player
	position otherPlayer;
	if (board.currentPlayer == cross) {
		otherPlayer = nought;
	} else {
		otherPlayer = cross;
	}

	// iterate over the board
	gameResult = otherPlayer;
	for (int i = 0; i < board.grid.numRows(); ++i) {
		for (int j = 0; j < board.grid.numCols(); ++j) {
			// if the given block is clear
			if (board.grid[i][j] == neither) {
				// create a new board and mark the move
				// of the current player on the given (i, j)
				boardT nextBoard = board;
				nextBoard.grid[i][j] = board.currentPlayer;
				// change the current player for the next move
				nextBoard.currentPlayer = otherPlayer;

				// continue recursion for the next possible moves
				// and get the final winner for the given board
				position currentResult = gameFinalResult(nextBoard);
				
				// update the current winner player
				if (board.currentPlayer == cross) {
					if (gameResult < currentResult) {
						gameResult = currentResult;
					}
				} else {
					if (gameResult > currentResult) {
						gameResult = currentResult;
					}
				}
			}
		}
	}
	return gameResult;
}

Grid<position> getTestGrid() {
	Grid<position> testGrid(TTT_ROWS, TTT_COLS);

	testGrid[0][0] = cross;
	testGrid[1][1] = nought;
	testGrid[2][2] = cross;
	testGrid[0][2] = nought;
	testGrid[2][0] = cross;

	return testGrid;
}

void printBoard(Grid<position>& board) {
	for (int i = 0; i < board.numRows(); ++i) {
		for (int j = 0; j < board.numCols(); ++j) {
			if (board[i][j] == cross) {
				cout << "X ";
			} else if (board[i][j] == nought) {
				cout << "O ";
			} else {
				cout << "_ ";
			}
		}
		cout << endl;
	}
}
