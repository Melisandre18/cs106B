#include "DGraph.h"
#include "queue.h"
#include "set.h"

DGraph::DGraph(int size) {
	numVertices = size;
	numEdges = 0;
	vertices = new Vertex[numVertices];
}

DGraph::~DGraph() {
	delete[] vertices;
}

int DGraph::size() {
	return numVertices;
}

int DGraph::edgeCount() {
	return numEdges;
}

void DGraph::addEdge(int i, int j) {
	if (!hasEdge(i, j)) {
		vertices[i].neighbours.insert(vertices + j);
        	++numEdges;
	}
}

void DGraph::removeEdge(int i, int j) {
	if (hasEdge(i, j)) {
		vertices[i].neighbours.remove(vertices + j);
        	--numEdges;
	}
}

bool DGraph::hasEdge(int i, int j) {
	return vertices[i].neighbours.contains(vertices + j);
}

bool DGraph::hasPath(int i, int j) {
	Set<Vertex*> visited;
	return hasPath(vertices + i, vertices + j, visited);
}

bool DGraph::hasPath(Vertex* start,
					 Vertex* finish,
					 Set<Vertex*> visited) {
	if (start == finish) {
		return true;
	}

	visited.insert(start);
	foreach (Vertex* next in start -> neighbours) {
		if (!visited.contains(next)) {
			if (hasPath(next, finish, visited)) {
				return true;
			}
		}
	}

	return false;
}

int DGraph::shortestPath(int i, int j) {
	Queue<Vertex*> yellow;
	Set<Vertex*> visited; // yellow and green combined
	yellow.enqueue(vertices + i);
	visited.insert(vertices + i);
	int distance = 0;
	int nodesLeftToConsider = 1; // at current distance
	
	while (!yellow.isEmpty()) {
		Vertex* curNode = yellow.dequeue();

		if (curNode == vertices + j) {
			return distance;
		}

		foreach (Vertex* neighbour in curNode -> neighbours) {
			if (!visited.contains(neighbour)) {
				yellow.enqueue(neighbour);
				visited.insert(neighbour);
			}
		}
		
		--nodesLeftToConsider;
		if (nodesLeftToConsider == 0) {
			++distance;
			nodesLeftToConsider = yellow.size();
		}
	}
	
	return -1;
}

int DGraph::numComponents() {
	int components = 0;
	Set<Vertex*> visited;
	Queue<Vertex*> q;
	
	for (int i = 0; i < numVertices; ++i) {
		if (!visited.contains(vertices + i)) {
			++components;
			q.enqueue(vertices + i);
			visited.insert(vertices + i);
			
			while (!q.isEmpty()) {
				Vertex* curNode = q.dequeue();
				foreach(Vertex* neighbour in curNode -> neighbours) {
					if (!visited.contains(neighbour)) {
						q.enqueue(neighbour);
						visited.insert(neighbour);
					}
				}
			}
		}
	}
	return components;
}
