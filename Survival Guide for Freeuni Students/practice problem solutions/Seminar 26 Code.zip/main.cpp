#include <iostream>
#include "console.h"
#include "DGraph.h"

int main() {
	DGraph graph(5);
	graph.addEdge(0, 3);
	graph.addEdge(3, 1);
	graph.addEdge(1, 2);
	graph.addEdge(0, 1);
	
	std::cout << "Min length of 0 -> 2: " << graph.shortestPath(0, 2) << std::endl;
	std::cout << "Connected parts: " << graph.numComponents() << std::endl;

	return 0;
}
