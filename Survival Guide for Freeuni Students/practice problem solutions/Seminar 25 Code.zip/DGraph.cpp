#include "DGraph.h"
#include "set.h"

DGraph::DGraph(int size) {
	numVertices = size;
	numEdges = 0;
	vertices = new Vertex[numVertices];
}

DGraph::~DGraph() {
	delete[] vertices;
}

int DGraph::size() {
	return numVertices;
}

int DGraph::edgeCount() {
	return numEdges;
}

void DGraph::addEdge(int i, int j) {
	if (!hasEdge(i, j)) {
		vertices[i].neighbours.insert(vertices + j);
		++numEdges;
	}
}

void DGraph::removeEdge(int i, int j) {
	if (hasEdge(i, j)) {
		vertices[i].neighbours.remove(vertices + j);
		--numEdges;
	}
}

bool DGraph::hasEdge(int i, int j) {
	return vertices[i].neighbours.contains(vertices + j);
}

bool DGraph::hasPath(int i, int j) {
	Set<Vertex*> visited;
	return hasPath(vertices + i, vertices + j, visited);
}

bool DGraph::hasPath(Vertex* start,
					 Vertex* finish,
					 Set<Vertex*> visited) {
	if (start == finish) {
		return true;
	}

	visited.insert(start);
	foreach (Vertex* next in start -> neighbours) {
		if (!visited.contains(next)) {
			if (hasPath(next, finish, visited)) {
				return true;
			}
		}
	}

	return false;
}
