#include <iostream>
#include "console.h"
#include "DGraph.h"

int main() {
	DGraph graph(4);
	graph.addEdge(0, 3);
	graph.addEdge(3, 1);
	graph.addEdge(3, 1);
	graph.addEdge(3, 2);
	
	std::cout << "Nuber of edges: " << graph.edgeCount() << std::endl;
	std::cout << "Number of vertices: " << graph.size() << std::endl;
	std::cout << "0 -> 1 ?: " << graph.hasPath(0, 1) << std::endl;
	std::cout << "2 -> 3 ?: " << graph.hasPath(2, 3) << std::endl;
	std::cout << "0 -> 2 ?: " << graph.hasPath(0, 2) << std::endl;
	
	std::cout << "\nRemoving 3 -> 2" << std::endl;
	graph.removeEdge(3, 2);
	std::cout << "0 -> 2 ?: " << graph.hasPath(0, 2) << std::endl;
	
	return 0;
}
