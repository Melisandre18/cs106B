#ifndef BST_H_
#define BST_H_

#include <string>

class BST {
public:
	BST();
	
	~BST();
	
	bool contains(int val);
	
	void insert(int val);

	std::string toString();

private:
	struct Node {
		int val;
		int priority;
		Node* left;
		Node* right;
	};
	Node* root;
	void deleteSubtree(Node* subtree);
	Node* findNode(Node* subtree, int value);
	void rotateLeft(Node*& subtree);
	void rotateRight(Node*& subtree);
	void insertInSubtree(Node*& subtree, Node* newNode);
	void serialize(Node* tree, std::string& soFar);
};

#endif
