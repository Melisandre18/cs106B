#include "BST.h"
#include <string>
#include "strlib.h"
#include "random.h"
#include "limits.h"

BST::BST() {
	root = NULL;
}

BST::~BST() {
	deleteSubtree(root);
}

void BST::deleteSubtree(Node* subtree) {
	if (subtree != NULL) {
		deleteSubtree(subtree -> left);
		deleteSubtree(subtree -> right);
		delete subtree;
	}
}

BST::Node* BST::findNode(Node* subtree, int val) {
	if (subtree == NULL || subtree -> val == val) {
		return subtree;
	}

	if (val < subtree -> val) {
		return findNode(subtree -> left, val);
	} else {
		return findNode(subtree -> right, val);
	}
}

bool BST::contains(int val) {
	return findNode(root, val) != NULL;
}

void BST::insert(int newVal) {
	Node* newNode = new Node;
	newNode -> val = newVal;
	newNode -> priority = randomInteger(0, INT_MAX);
	newNode -> left = NULL;
	newNode -> right = NULL;
	insertInSubtree(root, newNode);
}

void BST::insertInSubtree(Node*& subtree, Node* newNode) {
	if (subtree == NULL) {
		subtree = newNode;
		return;
	}
	
	if (newNode -> val < subtree -> val) {
		insertInSubtree(subtree -> left, newNode);
		if (subtree -> left -> priority < subtree -> priority) {
			rotateRight(subtree);
		}
	} else if (newNode -> val > subtree -> val) {
		insertInSubtree(subtree -> right, newNode);
		if (subtree -> right -> priority < subtree -> priority) {
			rotateLeft(subtree);
		}
	} else {
		delete newNode;
	}
}

void BST::rotateLeft(Node*& subtree) {
	Node* beta = subtree -> right -> left;
	subtree -> right -> left = subtree;
	subtree = subtree -> right;
	subtree -> left -> right = beta;
}

void BST::rotateRight(Node*& subtree) {
	Node* beta = subtree -> left -> right;
	subtree -> left -> right = subtree;
	subtree = subtree -> left;
	subtree -> right -> left = beta;
}

std::string BST::toString() {
	std::string result = "";
	serialize(root, result);
	return result;
}

void BST::serialize(Node* tree, std::string& soFar) {
	if (tree != NULL) {
		serialize(tree->left, soFar);
		soFar += integerToString(tree->val);
		soFar += " ";
		serialize(tree->right, soFar);
	}
}
