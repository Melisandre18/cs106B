#include <iostream>
#include "console.h"
#include "BST.h"

int main() {
	BST* bst = new BST();
	bst->insert(5);
	bst->insert(10);
	bst->insert(1231);
	bst->insert(-123);
	bst->insert(2);
	
	std::cout << bst->contains(2) << std::endl;
	std::cout << bst->contains(-2) << std::endl;

	std::cout << bst->toString() << std::endl;

	delete bst;

	return 0;
}
