/*
 * minesweeper.cpp
------------ * 
 * Various minesweeper related problem
 * solutions as of seminar live coding.
 */ 
#include <iostream>
#include "console.h"
#include "simpio.h"
#include "grid.h"
#include "random.h"
using namespace std;

const int ROWS = 8;
const int COLS = 12;
const double PROBABILITY = 0.1;
const int MINE_COUNT = 24;

// Function prototype
void createMineFieldWithProbability(Grid<bool>& result, double probability);
void createMineFieldWithCount(Grid<bool>& minefield, int numMines);
void calculateHints(Grid<int>& hints, Grid<bool>& minefield);
int getSingleHint(Grid<bool>& minefield, int row, int col);
bool isValidLocation(int i, int j, Grid<bool>& grid);
void getTopLeftRectangleSums(Grid<int>& rectangleSums, Grid<bool>& minefield);
int countBombsInRectangle(Grid<int>& rectangleSums, int x1, int y1,
						int x2, int y2);
int getRectangleSum(Grid<int>& rectangleSums, int x, int y);
void printMinefield(Grid<bool>& minefield);
void printHints(Grid<int>& hints);
void printSums(Grid<int>& rectangleSums);

int main() {
	// First variation of minefield initialization
	cout << "Placing mines by probability:" << endl;

	Grid<bool> minefield(ROWS, COLS);
	createMineFieldWithProbability(minefield, PROBABILITY);
	printMinefield(minefield);

	// Second variation of minefield initialization
	cout << "\nPlacing mines randomly by quantity:" << endl;

	Grid<bool> minefield2(ROWS, COLS);
	createMineFieldWithCount(minefield2, MINE_COUNT);
	printMinefield(minefield2);

	// Calculating hints
	cout << "\nPrinting hints:" << endl;

	Grid<int> hints(ROWS, COLS);
	calculateHints(hints, minefield2);
	printHints(hints);

	// Calculating top left rectangle sum
	cout << "\nPrinting rectangle sums:" << endl;

	Grid<int> rectangleSums(ROWS, COLS);
	getTopLeftRectangleSums(rectangleSums, minefield2);
	printSums(rectangleSums);

	// Calculating number of mines between two points in rectangle
	int x1 = getInteger("\nEnter x0: ");
	int y1 = getInteger("Enter y0: ");
	int x2 = getInteger("Enter x1: ");
	int y2 = getInteger("Enter y1: ");

	cout << "The number of mines between the given points is: ";
	cout << countBombsInRectangle(rectangleSums, x1, y1, x2, y2) << endl;

	return 0;
}

void createMineFieldWithProbability(Grid<bool>& result, double probability) {
	for (int i = 0; i < result.numRows(); ++i) {
		for (int j = 0; j < result.numCols(); ++j) {
			result[i][j] = randomChance(probability);
		}
	}
}

void createMineFieldWithCount(Grid<bool>& minefield, int numMines) {
	while (numMines > 0) {
		int y = randomInteger(0, minefield.numRows() - 1);
		int x = randomInteger(0, minefield.numCols() - 1);
		if (!minefield[y][x]) {
			--numMines;
			minefield[y][x] = true;
		}
	}
}

void calculateHints(Grid<int>& hints, Grid<bool>& minefield) {
	for (int i = 0; i < minefield.numRows(); ++i) {
		for (int j = 0; j < minefield.numCols(); ++j) {
			hints[i][j] = getSingleHint(minefield, i, j);
		}
	}
}

int getSingleHint(Grid<bool>& minefield, int row, int col) {
	if (minefield[row][col]) {
		return -1;
	}
	
	int result = 0;
	for (int i = row - 1; i <= row + 1; ++i) {
		for (int j = col - 1; j <= col + 1; ++j) {
			if (isValidLocation(i, j, minefield)) {
				if (minefield[i][j]) {
					++result;
				}
			}
		}
	}
	
	return result;
}

bool isValidLocation(int i, int j, Grid<bool>& grid) {
	return (i >= 0 && i < grid.numRows() 
		&& j >= 0 && j < grid.numCols());
}

void getTopLeftRectangleSums(Grid<int>& rectangleSums, Grid<bool>& minefield) {
	for (int x = 0; x < minefield.numCols(); ++x) {
		for (int y = 0; y < minefield.numRows(); ++y) {
			if (x == 0 && y == 0) {
				rectangleSums[y][x] = minefield[y][x];
			} else if (y == 0) {
				rectangleSums[y][x] = rectangleSums[y][x-1]
				+ minefield[y][x];
			} else if (x == 0) {
				rectangleSums[y][x] = rectangleSums[y-1][x]
				+ minefield[y][x];
			} else {
				rectangleSums[y][x] = rectangleSums[y-1][x]
					+ rectangleSums[y][x-1] - rectangleSums[y-1][x-1]
					+ minefield[y][x];
			}
		}
	}
}

int countBombsInRectangle(Grid<int>& rectangleSums, int x1, int y1,
						int x2, int y2) {
	return getRectangleSum(rectangleSums, x2, y2)
		- getRectangleSum(rectangleSums, x1-1, y2)
		- getRectangleSum(rectangleSums, x2, y1-1)
		+ getRectangleSum(rectangleSums, x1-1, y1-1);
}

int getRectangleSum(Grid<int>& rectangleSums, int x, int y) {
	if (x < 0 || y < 0) {
		return 0;
	} else {
		return rectangleSums[y][x];
	}
}

void printMinefield(Grid<bool>& minefield) {
	for (int i = 0; i < minefield.numRows(); ++i) {
		for (int j = 0; j < minefield.numCols(); ++j) {
			if (minefield[i][j]) {
				cout << "x ";
			} else {
				cout << "o ";
			}
		}
		cout << endl;
	}
}

void printHints(Grid<int>& hints) {
	for (int i = 0; i < hints.numRows(); ++i) {
		for (int j = 0; j < hints.numCols(); ++j) {
			cout << hints[i][j];
			if (hints[i][j] != -1) {
				cout << ' '; // a 'hack', because '-1' takes too much space
			}
			cout << ' ';
		}
		cout << endl;
	}
}

void printSums(Grid<int>& rectangleSums) {
	for (int i = 0; i < rectangleSums.numRows(); ++i) {
		for (int j = 0; j < rectangleSums.numCols(); ++j) {
			cout << rectangleSums[i][j] << "  ";
		}
		cout << endl;
	}
}
