/*
 * print-reverse.cpp
------------ * 
 * This program prints the numbers entered
 * by the user in reverse order.
 */ 
#include <iostream>
#include <string>
#include "console.h"
#include "simpio.h" // already includes <string>
#include "stack.h"
using namespace std;

// Function prototype
void printInReverse();

const int SENTINEL = -1;

int main() {
	printInReverse();

	return 0;
}

void printInReverse() {
	Stack<int> st;
	
	cout << "Sentinel input is " << SENTINEL << endl;

	while (true) {
		int currentInt = getInteger("Enter integer: ");
		
		if (currentInt == SENTINEL) {
			break;
		}
		st.push(currentInt);
	}

	while (!st.isEmpty()) {
		int currentInt = st.pop();
		cout << currentInt << " ";
	}
	cout << endl; // Stanford's console on Windows breaks without including endline
}
