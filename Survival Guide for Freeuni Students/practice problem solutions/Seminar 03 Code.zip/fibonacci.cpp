/*
 * fibonacci.cpp
------------ * 
 * This program calculates fibonacci sequence
 * numbers in an efficient way.
 */ 
#include <iostream>
#include <string>
#include "console.h"
#include "simpio.h" // already includes <string>
#include "stack.h"
using namespace std;

struct IntPairT {
	int first; // To store F(n)
	int second; // To store F(n+1)
};

// Function prototype
int fibonacci(int n);
IntPairT fibonacciPair(int n);

int main() {
	int n = getInteger("Enter number: ");
	cout << fibonacci(n) << endl;

	return 0;
}

int fibonacci(int n) {
	IntPairT result = fibonacciPair(n);
	return result.first;
}

IntPairT fibonacciPair(int n) {
	if (n == 0) {
		IntPairT result;
		result.first = 0; // F(n)
		result.second = 1; // F(n+1)
		return result;
	}

	// Get F(n-1) AND F(n)
	IntPairT previous = fibonacciPair(n-1);

	IntPairT result;
	result.first = previous.second; // F(n)
	result.second = previous.first + previous.second; // F(n+1)

	return result;
}
