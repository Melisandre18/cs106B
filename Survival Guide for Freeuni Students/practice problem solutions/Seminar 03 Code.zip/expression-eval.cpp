/*
 * expression-eval.cpp
------------ * 
 * This program evaluates arithemtic expressions
 * (with a support for simple operations).
 */ 
#include <iostream>
#include <string>
#include "console.h"
#include "simpio.h" // already includes <string>
#include "stack.h"
using namespace std;

// Function prototype
int evaluateExpression(string str);

int main() {
	string expression = getLine("Enter expression: ");
	
	int result = evaluateExpression(expression);
	cout << result << endl;

	return 0;
}

/**
 * Simplified version:
 * - All numbers have single digits [0..9]
 * - Every open brace is followed by a number
 */
int evaluateExpression(string str) {
	Stack<int> savedValues;
	bool firstInteger = true;
	int currentValue;

	for (int i = 0; i < str.length(); ++i) {
		if (str[i] == '-') {
			// currently supports only subtraction
			// but can be easily extended for other
			// arithmetic operations
		} else if (str[i] == '(') {
			savedValues.push(currentValue);
			firstInteger = true;
		} else if (str[i] == ')') {
			currentValue = savedValues.pop() - currentValue;
		} else {
			if (firstInteger) {
				currentValue = (str[i] - '0');
				firstInteger = false;
			} else {
				currentValue -= (str[i] - '0');
            }
		}
	}
	return currentValue;
}
