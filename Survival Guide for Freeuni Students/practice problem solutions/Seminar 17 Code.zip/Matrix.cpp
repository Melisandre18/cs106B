#include "Matrix.h"
#include "strlib.h"

Matrix::Matrix(int width, int height) {
	this->width = width;
	this->height = height;
	data = new double[width*height];
	
	for (int i = 0; i < width*height; ++i) {
		data[i] = 0.0;
	}
}

Matrix::Matrix(const Matrix& other) {
	this->width = other.width;
	this->height = other.height;
	data = new double[width*height];
	
	for (int i = 0; i < width*height; i++) {
		data[i] = other.data[i];
	}
}

Matrix::~Matrix() {
	delete[] data;
}

double Matrix::getAt(int row, int col) {
	return data[row*width + col];
}

void Matrix::setAt(int row, int col, double val) {
	data[row*width + col] = val;
}

void Matrix::addAt(int row, int col, double val) {
	data[row*width + col] += val;
}

Matrix Matrix::add(Matrix& other) {
	Matrix result(width, height);
	
	for (int i = 0; i < width*height; ++i) {
		result.data[i] = data[i] + other.data[i];
	}
	return result;
}

Matrix Matrix::times(Matrix& other) {
	Matrix result(other.width, height);
	
	for (int row = 0; row < height; ++row) {
		for (int col = 0; col < other.width; ++col) {
			for (int k = 0; k < width; ++k) {
				result.addAt(row, col, getAt(row, k) * other.getAt(k, col));
			}
		}
	}

	return result;
}

std::string Matrix::toString() {
	std::string result = "";
	for (int i = 0; i < width * height; ++i) {
		result += realToString(data[i]);
		
		if (i % width == width-1) {
			result += "\n";
		} else {
			result += " ";
		}
	}

	return result;
}
