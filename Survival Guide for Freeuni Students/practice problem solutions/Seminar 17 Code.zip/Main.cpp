#include <iostream>
#include "console.h"
#include "Matrix.h"
using namespace std;

int main() {
	Matrix* matrix1 = new Matrix(2, 2);
	matrix1->setAt(/* row = */ 0, /* col = */ 0, 5.0);
	matrix1->setAt(/* row = */ 1, /* col = */ 1, 6.0);
	matrix1->setAt(/* row = */ 0, /* col = */ 1, 2.0);

	cout << "Matrix 1:\n" << matrix1->toString() << endl;
	cout << endl;

	Matrix* matrix2 = new Matrix(4, 2);
	matrix2->setAt(/* width = */ 0, /* height = */ 0, 1.0);
	matrix2->setAt(/* width = */ 1, /* height = */ 1, 1.0);

	cout << "Matrix 2:\n" << matrix2->toString() << endl;
	cout << endl;
	
	Matrix product = matrix1->times(*matrix2);
	cout << "Product:\n" << product.toString() << endl;

	delete matrix1;
	delete matrix2;

	return 0;
}
