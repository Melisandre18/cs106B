#include "BST.h"
#include <string>
#include "strlib.h"

void BST::deleteSubtree(Node* subtree) {
	if (subtree != NULL) {
		deleteSubtree(subtree -> left);
		deleteSubtree(subtree -> right);
		delete subtree;
	}
}

BST::Node*& BST::findValue(Node*& subtree, int val) {
	if (subtree == NULL || subtree -> val == val) {
		return subtree;
	}

	if (val < subtree -> val) {
		return findValue(subtree -> left, val);
	} else {
		return findValue(subtree -> right, val);
	}
}

BST::BST() {
	root = NULL;
}

BST::~BST() {
	deleteSubtree(root);
}

bool BST::contains(int val) {
	return findValue(root, val) != NULL;
}

void BST::insert(int val) {
	Node*& destination = findValue(root, val);
	if (destination == NULL) {
		destination = new Node;
		destination -> val = val;
		destination -> left = NULL;
		destination -> right = NULL;
	}
}

std::string BST::toString() {
	std::string result = "";
	serialize(root, result);
	return result;
}

void BST::serialize(Node* tree, std::string& soFar) {
	if (tree != NULL) {
		serialize(tree->left, soFar);
		soFar += integerToString(tree->val);
		soFar += " ";
		serialize(tree->right, soFar);
	}
}
