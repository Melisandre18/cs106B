#ifndef BST_H_
#define BST_H_

#include <string>

class BST {
public:
	BST();
	
	~BST();
	
	bool contains(int val);
	
	void insert(int val);

	std::string toString();

private:
	struct Node {
		int val;
		Node* left;
		Node* right;
	};
	
	Node* root;
	void deleteSubtree(Node* subtree);
	Node*& findValue(Node*& subtree, int val);
	void serialize(Node* tree, std::string& soFar);
};

#endif
