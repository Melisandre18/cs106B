/*
 * clique.cpp
 * ------------
 * Solutions to various clique problems. See
 * problem handout for details.
 */

#include <iostream>
#include "console.h"
#include "simpio.h"
#include "strlib.h"
#include "grid.h"
using namespace std;

const int NUM_ROWS = 4;
const int NUM_COLS = 4;

// Function prototypes
bool isClique(Grid<bool>& graph, Vector<int> indices);
bool isConnectedToOthers(Grid<bool>& graph, int vertex, Vector<int> others);
int maxSizeClique(Grid<bool>& graph);
int maxSizeCliqueWithSubset(Grid<bool>& graph, Vector<int>& chosenSet, int firstFreeIndex);
Grid<bool> getTestGrid();
void printBoard(Grid<bool>& board);

int main() {
	// Initialize test grid for demo purposes
	Grid<bool> grid = getTestGrid();
	printBoard(grid);

	Vector<int> indices;
	indices.add(0);
	indices.add(1);
	indices.add(2);

	bool shouldBeClique = isClique(grid, indices);
	cout << "\nDo 0, 1 and 2 make clique? - " << shouldBeClique << endl;

	indices.add(3);
	bool shouldNotBeClique = isClique(grid, indices);
	cout << "Do 0, 1, 2 and 3 make clique? - " << shouldNotBeClique << endl;

	cout << "\nMax clique for given graph is " << maxSizeClique(grid) << endl;
	return 0;
}

bool isClique(Grid<bool>& graph, Vector<int> indices) {
	if (indices.size() <= 1) {
		return true;
	}
	
	int removedVertex = indices[indices.size() - 1];
	indices.remove(indices.size() - 1);
	
	return isConnectedToOthers(graph, removedVertex, indices) && isClique(graph, indices);
}

bool isConnectedToOthers(Grid<bool>& graph, int vertex, Vector<int> others) {
	foreach(int index in others) {
		if (!graph[vertex][index]) {
			return false;
		}
	}
	return true;
}

int maxSizeClique(Grid<bool>& graph) {
	Vector<int> emptySet;
	return maxSizeCliqueWithSubset(graph, emptySet, 0);
}

int maxSizeCliqueWithSubset(Grid<bool>& graph,
							Vector<int>& chosenSet,
							int firstFreeIndex) {
	if (firstFreeIndex == graph.numCols()) {
		if (isClique(graph, chosenSet)) {
			return chosenSet.size();
		} else {
			return -1;
		}
	}

	int maxSizeWithoutFirst = maxSizeCliqueWithSubset(graph,
		chosenSet,
		firstFreeIndex + 1);

	chosenSet.add(firstFreeIndex);
	int maxSizeWithFirst = maxSizeCliqueWithSubset(graph,
		chosenSet,
		firstFreeIndex + 1);
	chosenSet.remove(chosenSet.size() - 1);

	return max(maxSizeWithFirst, maxSizeWithoutFirst);
}

Grid<bool> getTestGrid() {
	Grid<bool> testGrid(NUM_ROWS, NUM_COLS);

	// 0 <-> 2
	testGrid[0][2] = true;
	testGrid[2][0] = true;

	// 0 <-> 1
	testGrid[0][1] = true;
	testGrid[1][0] = true;

	// 1 <-> 2
	testGrid[1][2] = true;
	testGrid[2][1] = true;

	// 3 <-> 1
	testGrid[1][3] = true;
	testGrid[3][1] = true;

	return testGrid;
}

void printBoard(Grid<bool>& board) {
	cout << "   ";
	for (int i = 0; i < board.numCols(); ++i) {
		cout << i << " ";
	}
	cout << endl;

	for (int i = 0; i < board.numRows(); ++i) {
		cout << i << "| ";
		for (int j = 0; j < board.numCols(); ++j) {
			if (board[i][j]) {
				cout << "X ";
			} else {
				cout << "_ ";
			}
		}
		cout << endl;
	}
}
