/*
 * swap-min.cpp
------------ * 
 * This program swaps the first character of the given string
 * with the smallest ASCII value character found in it.
 */ 
#include <iostream>
#include <string>
#include "console.h"
#include "simpio.h" // already includes <string>
using namespace std;

// Function prototype
string swapMinWithFirst(string s);

int main() {
	string str = getLine("Enter desired string: ");

	cout << "Swapped version: " << swapMinWithFirst(str) << endl;
	
	return 0;
}

string swapMinWithFirst(string s) {
	if (s.length() == 0) {
		return s;
	}
	
	int currentMinIndex = 0;
	for (int i = 0; i < s.length(); ++i) {
		if (s[i] < s[currentMinIndex]) {
			currentMinIndex = i;
		}
	}

    string result = s;
    result[0] = s[currentMinIndex];
    result[currentMinIndex] = s[0];

	return result;
}