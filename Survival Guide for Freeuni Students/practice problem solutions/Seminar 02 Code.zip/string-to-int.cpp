/*
 * string-to-int.cpp
------------ * 
 * This program recursively converts numeral literal
 * to integer.
 */ 
#include <iostream>
#include <string>
#include "console.h"
#include "simpio.h" // already includes <string>
using namespace std;

// Function prototype
string getNumeralString();
bool isInteger(string s);
int convertToInteger(string s);

int main() {
	string numeralStr = getNumeralString();
	
	int converted = convertToInteger(numeralStr);

	cout << "Converted: " << converted << endl;
	
	return 0;
}

string getNumeralString() {
	while (true) {
		string input = getLine("Enter desired numeral string: ");

		if (isInteger(input)) {
			return input;
		} else {
			cout << "Please make sure the string is numeral" << endl;
		}
    }
}

bool isInteger(string s) {
	if (s.length() == 0) {
		return false;
	}
	
	for (int i = 0; i < s.length(); ++i) {
		if (s[i] < '0' || s[i] > '9') {
			return false;
		}
	}
	
	return true;
}

int convertToInteger(string s) {
	if (s.length() == 0) {
		return 0;
	}

	int lastDigit = s[s.length() - 1] - '0';
	int minusLastDigit = convertToInteger(s.substr(0, s.length() - 1)) * 10;
	return minusLastDigit + lastDigit;
}
