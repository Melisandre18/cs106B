/*
 * mod7.cpp
------------ * 
 * This program recursively finds the remainder of the numeral
 * string with mod 7.
 */ 
#include <iostream>
#include <string>
#include "console.h"
#include "simpio.h" // already includes <string>
using namespace std;

// Function prototype
string getNumeralString();
bool isInteger(string s);
int remainderMod7(string s);

int main() {
	string numeralStr = getNumeralString();
	
	int mod7 = remainderMod7(numeralStr);

	cout << numeralStr << " mod 7 = " << mod7 << endl;
	
	return 0;
}

string getNumeralString() {
	while (true) {
		string input = getLine("Enter desired numeral string: ");

		if (isInteger(input)) {
			return input;
		} else {
			cout << "Please make sure the string is numeral" << endl;
		}
    }
}

bool isInteger(string s) {
	if (s.length() == 0) {
		return false;
	}
	
	for (int i = 0; i < s.length(); ++i) {
		if (s[i] < '0' || s[i] > '9') {
			return false;
		}
	}
	
	return true;
}

int remainderMod7(string s) {
	if (s.length() == 1) {
		return (s[0] - '0') % 7;
	}
	
	int lastDigit = s[s.length() - 1] - '0';
	int minusLastDigitRem = remainderMod7(s.substr(0, s.length() - 1)) * 3;
	return (minusLastDigitRem + lastDigit) % 7;
}
