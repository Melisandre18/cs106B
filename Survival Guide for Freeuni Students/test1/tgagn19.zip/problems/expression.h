#ifndef _expression_
#define _expression_

#include "console.h"
#include "Set.h"
using namespace std;


int getExpressionNum(int num, Set<int> nums);

#endif