#include <string>
#include "Vector.h"

using namespace std;

bool giveChange(Vector<int> &cshBills, Vector<int> &cstBills, int price);