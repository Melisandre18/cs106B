#include <string>
#include "Set.h"
#include "Map.h"

using namespace std;

string recallPass(Map<char, int> &map, bool (*isCorrectPass)(string s));