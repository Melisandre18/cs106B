#include <string>
#include "Vector.h"

using namespace std;

int calcTranslTime(Vector<int> times);