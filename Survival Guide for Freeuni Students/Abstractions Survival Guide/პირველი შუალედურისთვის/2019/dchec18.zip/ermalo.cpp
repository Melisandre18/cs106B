#include "ermalo.h"


using namespace std;
/*
	if (isCorrectPass("a")) {
		return "a";
	}
*/
string recallPassword(Map<char, int> &map, bool (*isCorrectPass)(string s),string s){
	if(map.isEmpty()){
		if (isCorrectPass(s)) {
			return s;
		}
		return "";
	}else{ 
		foreach(char c in map){
			if(map[c]>0){
				s += c;
				map[c]--;
				if(map[c] == 0) map.remove(c);
				string correctPass = recallPassword(map,isCorrectPass,s);
				if(correctPass.length()>0) {
					return correctPass;
				}
				if(!map.containsKey(c)){
					map.put(c,0);
				}
				map[c]++;
				s=s.substr(0,s.length()-1);
			}
		}
	}


	return "";
}

string recallPass(Map<char, int> &map, bool (*isCorrectPass)(string s)) {
	return recallPassword(map,isCorrectPass,"");
}

