#include "Grid.h"

int maxPairs(Grid<bool> &likes);