#include "Grid.h"

int maxPairsSol(Grid<bool> &likes);