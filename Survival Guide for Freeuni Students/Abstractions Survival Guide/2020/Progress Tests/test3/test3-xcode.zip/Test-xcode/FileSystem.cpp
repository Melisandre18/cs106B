//
//  FileSystem.cpp
//  ProgressTest
//
//  Created by Mikheil on 6/6/20.
//

#include "FileSystem.h"

FileSystem::FileSystem() {
    //TODO
}


string FileSystem::getActiveFolderName() {
    //TODO
    return "";
}


Vector<string> FileSystem::getFolderList() {
    //TODO
    Vector<string> names;
    return names;
}


Vector<string> FileSystem::getFileList() {
    //TODO
    Vector<string> names;
    return names;
}


bool FileSystem::createFolder(string name) {
    //TODO
    return false;
}


bool FileSystem::createFile(string name) {
    //TODO
    return false;
}


bool FileSystem::selectFolder(string name) {
    //TODO
    return false;
}


void FileSystem::up() {
    // TODO
}


string FileSystem::searchFile(string fileName) {
    // TODO
    return "";
}
