#include "LangRank.h"

Map<char, int> getLangRanks (Grid<char> grid) {
	Map<char, int> res;

	return res;
}
