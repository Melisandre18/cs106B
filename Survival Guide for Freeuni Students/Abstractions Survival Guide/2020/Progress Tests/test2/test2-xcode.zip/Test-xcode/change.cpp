#include "change.h"


bool giveChange(Vector<int> &cshBills, Vector<int> &cstBills, int price) {
    // TODO
	return false;
}
