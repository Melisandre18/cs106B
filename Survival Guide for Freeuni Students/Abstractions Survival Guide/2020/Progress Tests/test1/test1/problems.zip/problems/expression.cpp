#include "expression.h"
#include "strlib.h"

int getExpressionNumRec(int num, Set<int> nums) {
	if (nums.isEmpty()) {
		return num == 0 ? 1 : 0;
	}

	int res = 0;
	int first = nums.first();
	res += getExpressionNumRec(num, nums - first);
	res += getExpressionNumRec(num-first, nums - first);
	res += getExpressionNumRec(num+first, nums - first);

	return res;
}

int getExpressionNum(int num, Set<int> nums) {
	return getExpressionNumRec(num, nums);
}