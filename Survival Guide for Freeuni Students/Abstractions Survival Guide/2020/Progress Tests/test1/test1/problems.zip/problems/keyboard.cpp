#include "keyboard.h"
#include "strlib.h"


char arr[] = {'?', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };


void getAllEncryptionMine(string digits, string soFar, Set<string> &words, Lexicon &lex) {
	if (!lex.containsPrefix(soFar))
		return;

	if (digits == "") {
		if (lex.contains(soFar))
			words.add(soFar);
		return;
	}

	getAllEncryptionMine(digits.substr(1), soFar + arr[digits[0] - '0'], words, lex);
	if (digits.length() < 2)
		return;
	int i = stringToInteger(digits.substr(0, 2));
	if (digits[0] != '0' && i < 26)
		getAllEncryptionMine(digits.substr(2), soFar + arr[i], words, lex);
}


void getAllEncryption(string digits, Set<string> &words, Lexicon &lex) {
	getAllEncryptionMine(digits, "", words, lex);
}
