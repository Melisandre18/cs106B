#include "expression.h"
#include "strlib.h"


int getExpressionNum(int num, Set<int> nums) {
    // TODO
	return -1;
}
