#ifndef _expression_
#define _expression_

#include "console.h"
#include "set.h"
using namespace std;


int getExpressionNum(int num, Set<int> nums);

#endif
