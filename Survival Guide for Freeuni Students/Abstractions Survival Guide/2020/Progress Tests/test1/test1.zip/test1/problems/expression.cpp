#include "expression.h"
#include "strlib.h"


int getExpressionNum(int num, Set<int> nums) {
	return -1;
}