#include "FileSystem.h"

FileSystem::FileSystem() {
}


string FileSystem::getActiveFolderName() {
	return "";
}

Vector<string> FileSystem::getFolderList() {
	Vector<string> names;
	return names;
}

Vector<string> FileSystem::getFileList() {
	Vector<string> names;
	return names;
}

bool FileSystem::createFolder(string name) {
	return false;
}

bool FileSystem::createFile(string name) { 
	return false;
}

bool FileSystem::selectFolder(string name) { 
	return false;
}

void FileSystem::up() {
}

string FileSystem::searchFile(string fileName) { 
	return ""; 
}


