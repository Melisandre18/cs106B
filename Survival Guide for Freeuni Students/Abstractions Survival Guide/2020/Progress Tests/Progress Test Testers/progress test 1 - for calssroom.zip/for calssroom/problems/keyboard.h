#ifndef _keyboard_
#define keyboard_

#include "console.h"
#include "Set.h"
#include "lexicon.h"

using namespace std;

void getAllEncryption(string digits, Set<string> &words, Lexicon &lex);


#endif