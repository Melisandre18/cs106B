#include "keyboard.h"
#include "strlib.h"


char arrSol[] = {'?', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };


void getAllEncryptionSolMine(string digits, string soFar, Set<string> &words, Lexicon &lex) {
	if (!lex.containsPrefix(soFar))
		return;

	if (digits == "") {
		if (lex.contains(soFar))
			words.add(soFar);
		return;
	}

	getAllEncryptionSolMine(digits.substr(1), soFar + arrSol[digits[0] - '0'], words, lex);
	if (digits.length() < 2)
		return;
	int i = stringToInteger(digits.substr(0, 2));
	if (digits[0] != '0' && i < 26)
		getAllEncryptionSolMine(digits.substr(2), soFar + arrSol[i], words, lex);
}


void getAllEncryptionSol(string digits, Set<string> &words, Lexicon &lex) {
	getAllEncryptionSolMine(digits, "", words, lex);
}
