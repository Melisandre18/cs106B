#ifndef _keyboard_
#define keyboard_

#include "console.h"
#include "Set.h"
#include "lexicon.h"

using namespace std;

void getAllEncryptionSol(string digits, Set<string> &words, Lexicon &lex);


#endif