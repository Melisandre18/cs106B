#include "expressionsol.h"
#include "strlib.h"


int getPermCount(Set<int> nums, int num, string exp) {
	if (num == 0 && nums.isEmpty()) {
		//cout  << exp << endl;
		return 1;
	}
	if (nums.isEmpty()) 
		return 0;

	int v = nums.first();
	int res =	getPermCount(nums-v, num-v, exp + '+' + integerToString(v)) + 
				getPermCount(nums-v, num+v, exp + '-' + integerToString(v));
	return res;
}

void countRec(Set<int> soFar, Set<int> rest, int &res, int num) {
	if (rest.size() == 0) {
		//cout << soFar << endl;
		res += getPermCount(soFar, num, "");
		return;
	}
	int v = rest.first();
	countRec(soFar, rest-v, res, num);
	countRec(soFar + v, rest-v, res, num);
}

int getExpressionNumSol(int num, Set<int> nums) {
	Set<int> soFar;
	int res = 0;
	countRec(soFar, nums, res, num);
	return res;
}