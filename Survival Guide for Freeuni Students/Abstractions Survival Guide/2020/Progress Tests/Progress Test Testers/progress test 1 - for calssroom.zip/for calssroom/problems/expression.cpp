#include "expression.h"
#include <iostream>
//#include <string>
#include "strlib.h"
#include "set.h"
#include "vector.h"
#include "console.h"
#include "foreach.h"
using namespace std;

int getExpressionNum(int num, Set<int> nums) {
	return -2;
}
