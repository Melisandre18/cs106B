#ifndef _expression_sol_
#define _expression_sol_

#include "console.h"
#include "Set.h"
using namespace std;


int getExpressionNumSol(int num, Set<int> nums);

#endif