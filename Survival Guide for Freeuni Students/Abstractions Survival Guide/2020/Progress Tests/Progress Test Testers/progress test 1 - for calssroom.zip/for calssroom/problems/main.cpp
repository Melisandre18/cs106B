#include <iostream>
#include <fstream>

#include <string>
#include "simpio.h"
#include "vector.h"
#include "random.h"
#include "queue.h"
#include <time.h>
#include "lexicon.h"
#include "..\..\problems\expression.h"
#include "..\..\problems\expressionsol.h"
#include "..\..\problems\keyboard.h"
#include "..\..\problems\keyboardsol.h"


#define TEST_RESULTS_FOLDER_PATH "D:\\freeuni\\courses\\cs106b\\exams repo\\cs106b\\testing\\"
#define PROJECT_ROOT_FOLDER "D:\\freeuni\\courses\\cs106b\\exams repo\\cs106b\\2020\\progress test 1\\testing\\project\\Blank Project\\"

Lexicon lex;

void printTestResults(bool passed, int testNum, int & passedCounter) {
	if (passed) {
		passedCounter++;
		cout << "test " << testNum << " passed, total passed " << passedCounter << endl;
	} else {
		cout << "test " << testNum << " failed, total passed " << passedCounter << endl;
	}
}

void generateRandomSet(Set<int> & s, int testNum) {
	s.clear();
	switch (testNum) {
		case 0: s += 2, 4, 6, 12; break;
		case 1: s += 2, 4, 8, 11, 15; break;
		case 2: s += 0, 5, 7, 13, 14, 15; break;
		case 3: s += 2, 4, 5, 6, 10, 11, 13; break;
		case 4: s += 1, 2, 3, 5, 8, 11, 18, 21; break;
		case 5: s += 3, 4, 7, 12; break;
		case 6: s += 1, 2, 5, 12, 13; break;
		case 7: s += 1, 5, 6, 11, 13, 18; break;
		case 8: s += 2, 4, 7, 12, 13, 16, 18; break;
		case 9: s += 1, 5, 8, 10, 12, 15, 16, 19; break;
		case 10: s += 1, 3, 4, 11; break;
		case 11: s += 2, 5, 6, 10, 11; break;
		case 12: s += 0, 3, 6, 7, 17, 18; break;
		case 13: s += 0, 5, 7, 9, 14, 15, 18; break;
		case 14: s += 2, 4, 8, 10, 11, 17, 21, 23; break;
		case 15: s += 4, 6, 7, 9; break;
		case 16: s += 3, 5, 6, 8, 15; break;
		case 17: s += 1, 5, 7, 9, 12, 13; break;
		case 18: s += 0, 3, 5, 6, 8, 13, 18; break;
		case 19: s += 0, 2, 10, 12, 14, 15, 20, 21, 27; break;
	}
}
#define EXPR_TEST_NUM 20

bool runExpressionSingleTest(int testNum) {
	Set<int> nums;
	generateRandomSet(nums, testNum);
	bool passed = true;
	for (int j=7; j<11; j++) {
		passed = passed && (getExpressionNumSol(j, nums) == getExpressionNum(j, nums));
	}
	return passed;
}

void runExpressionTests() {
	cout << "### Run Expression tests ###" << endl;
	bool passed = false;
	int passedCounter = 0;
	
	for (int testNum=0; testNum<EXPR_TEST_NUM; testNum++) {
		printTestResults(runExpressionSingleTest(testNum), testNum, passedCounter);		
	}

	cout << "###### passed " << passedCounter << " tests ######" << endl;
}

bool contains(string * arr, int len, string val) {
	for (int i=0; i<len; i++) {
		if (arr[i] == val)
			return true;
	}
	return false;
}

#define KEYBOARD_TEST_NUM 20
const string keyboardTests[] = { "123", "1221", "312112", "312125", "612114", "711325", "712525", "815124", "1115121", "1122119", "1181119", "1191919", "1215225", "1217518", "1315311", "1412519", "1511119", "1611819", "1911919", "1912125"
			//"1415", "1225", "122519", "191254", "211419", "221181", "2015", "20815", "2152", "2352", "23554"
};


bool runKeyboardSingleTest(int testNum) {
	Set<string> s, s1;
	getAllEncryption(keyboardTests[testNum], s, lex);
	getAllEncryptionSol(keyboardTests[testNum], s1, lex);
	return s1 == s;
}

void runKeyboardTests(){
	//{"ado", "nae", "no"}1415
	//{"abbe", "aby", "ave"}1225
	//{"abbes", "abys", "aves"}122519
	//{"ailed", "sabed", "sled"}191254
	//{"bans", "unai", "uns"}211419
	//{"bura", "vara"}221181
	//{"tae", "to"}2015
	//{"thae", "tho"}20815
	//{"bob"}2152
	//{"web"}2352
	//{"weed"}23554

	//ofstream file;
	//file.open("1.txt");
	lex = Lexicon("EnglishWords.dat");	
	cout << "Run Keyboard tests!" << endl;
	int passedCounter = 0;
	for (int testNum=0; testNum<KEYBOARD_TEST_NUM; testNum++) {
		printTestResults(runKeyboardSingleTest(testNum), testNum, passedCounter);		
	}

	cout << "###### passed " << passedCounter << " tests ######" << endl;
}


int main() {
	runExpressionTests();
	runKeyboardTests();

	return 0;
}