#include <iostream>
#include <string>
#include "simpio.h"
#include "console.h"
#include "vector.h"
#include "queue.h"
#include <time.h>
#include "lexicon.h"
#include "change.h"
#include "changeSol.h"


using namespace std;

void printTestResults(bool passed, int testNum, int & passedCounter) {
	testNum++;
	if (passed) {
		cout << "test " << testNum << " passed" << endl;
		passedCounter++;
	} else {
		cout << "test " << testNum << " failed" << endl;
	}
}

#define CHANGE_TEST_NUM 20
int prices[CHANGE_TEST_NUM] = {4, 6, 5, 26, 39, 339, 339, 339, 29, 17, 7, 50, 20, 310, 710, 10, 1, 30, 23, 5};

void generateRandomVector(int testNum, Vector<int> &vCustomer, Vector<int> &vCashier) {
	switch (testNum) {
		case 0: 
			vCustomer += 15, 30, 120, 1, 3; 
			break;
		case 1: 
			vCustomer += 35, 30, 1, 3, 7; 
			vCashier += 1, 3, 7; 
			break;
		case 2: 
			vCustomer += 3;
			vCashier += 102, 2, 8;
			break;
		case 3: 
			vCustomer += 1, 13, 17, 22, 10; 
			vCashier += 3, 7, 15;
			break;
		case 4: 
			vCustomer += 1, 13, 18, 22, 10; 
			vCashier += 3, 7, 15, 27;
			break;
		case 5: 
			vCustomer += 100, 140, 160, 180, 200, 240, 340; 
			vCashier += 3, 7, 15, 27, 30, 48;
			break;
		case 6: 
			vCustomer += 100, 140, 160, 180, 200, 240, 340; 
			vCashier += 3, 7, 15, 27, 30, 48;
			break;
		case 7: 
			vCustomer += 107, 140, 160, 180, 200, 240, 340; 
			vCashier += 3, 7, 15, 27, 30, 50;
			break;
		case 8: 
			vCustomer += 10, 140, 160, 180, 200, 240, 340, 400, 430, 32; 
			vCashier += 7, 15, 27, 30, 50, 3;
			break;
		case 9: 
			vCustomer += 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2056; 
			vCashier += 12, 14, 26, 48, 52, 1052;
			break;
		case 10: 
			vCustomer += 1001, 1000, 120, 160, 180, 1, 1, 1, 1, 1, 1; 
			vCashier += 102, 200, 300, 800, 2500, 2300, 1200, 1400, 1004;
			break;
		case 11: 
			vCustomer += 5, 5, 5, 5, 5, 5, 24; 
			vCashier += 1, 1, 1, 1;
			break;
		case 12: 
			vCustomer += 13, 227, 38, 101, 180, 204, 288, 128, 208, 13; 
			vCashier += 10000, 10011, 1, 1, 5, 5;
			break;
		case 13: 
			vCustomer += 1, 10, 17, 28, 58, 60, 35, 70, 75; 
			vCashier += 1, 1, 3, 100, 20, 6, 102, 84, 56, 10, 5, 5, 5, 5, 5;
			break;
		case 14: 
			vCustomer += 1, 10, 17, 28, 40, 58, 60, 35, 70, 75; 
			vCashier += 1, 1, 3, 100, 20, 6, 84, 56, 10, 5, 5;
			break;
		case 15: 
			vCustomer += 4, 6, 7, 9; 

			break;
		case 16: 
			vCustomer += 3, 5, 6, 8, 15; 
			vCashier += 3, 1, 1;
			break;
		case 17: 
			vCustomer += 1, 5, 7, 9, 12, 13; 
			vCashier += 3, 1, 1;
			break;
		case 18: 
			vCustomer += 0, 3, 5, 6, 8, 13, 18; 
			vCashier += 3, 1, 1;
			break;
		case 19: 
			vCustomer += 0, 2, 10, 12, 14, 15, 20, 21, 27; 
			vCashier += 1, 1;
			break;
	}
}


bool runChangeSingleTest(int testNum) {
	Vector<int> cshBills, cstBills;
	Vector<int> cshBillsCopy, cstBillsCopy;
	generateRandomVector(testNum, cstBills, cshBills);
	cshBillsCopy = cshBills;
	cstBillsCopy = cstBills;
	bool res1 = giveChange(cshBills, cstBills, prices[testNum]);
	bool res2 = giveChangeSol(cshBillsCopy, cstBillsCopy, prices[testNum]);
	bool passed = res1 == res2;
	
	cshBills.clear();
	cshBillsCopy.clear();
	res1 = giveChange(cshBills, cstBills, prices[testNum]);
	res2 = giveChangeSol(cshBillsCopy, cstBillsCopy, prices[testNum]);
	passed = passed && res1 == res2;

	cstBills.clear();
	cstBillsCopy.clear();
	res1 = giveChange(cshBills, cstBills, prices[testNum]);
	res2 = giveChangeSol(cshBillsCopy, cstBillsCopy, prices[testNum]);
	passed = passed && res1 == res2;

	return passed;
}

void runChangeTests() {
	cout << "### Run Change tests ###" << endl;
	int passedNum = 0;
	for (int i=0; i<CHANGE_TEST_NUM; i++) {
		printTestResults(runChangeSingleTest(i), i, passedNum);
	}
	cout << "###### passed " << passedNum << " tests ######" << endl;
}

int main() {
	runChangeTests();
	return 0;
}
