#include <string>
#include "Vector.h"

using namespace std;

bool giveChangeSol(Vector<int> &cshBills, Vector<int> &cstBills, int price);