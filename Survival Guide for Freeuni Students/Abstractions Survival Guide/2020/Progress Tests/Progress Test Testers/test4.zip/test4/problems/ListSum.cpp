#include "ListSum.h"

digit * sum(digit * first, digit* second) {
	return NULL;	
}


