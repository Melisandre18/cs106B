#include "bigInteger.h"
#include "strlib.h"

	
BigInteger::BigInteger() {
}
BigInteger::~BigInteger() {
}

void BigInteger::setValue(string num) {
}
string BigInteger::toString() {
	return "";
}
void BigInteger::add(BigInteger &num) {
	
}

void BigInteger::insertDigit(int digit, int pos){
}

void BigInteger::removeDigit(int pos) {
}
