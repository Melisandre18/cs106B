#include <iostream>
#include <string>
#include <fstream>
#include "simpio.h"
#include "random.h"
#include "console.h"
#include "vector.h"
#include "foreach.h"
#include <time.h>
#include "lexicon.h"
#include "Set.h"
#include "Map.h"
#include "bigInteger.h"
#include "duplicateTree.h"
//#include <vld.h>


using namespace std;

void printTestResults(bool passed, int & testNum, int & passedCounter) {
	testNum++;
	if (passed) {
		cout << "test " << testNum << " passed" << endl;
		passedCounter++;
	} else {
		cout << "test " << testNum << " failed" << endl;
	}
}

void clearWeights(nodeT * root) {
	if (root == NULL) {
		return;
	}
	root->weight = 0;
	clearWeights(root->left);
	clearWeights(root->right);
}

nodeT* insertNode(nodeT * &root, int value, int weight) {
	if (root == NULL) {
		root = new nodeT;
		root->v = value;
		root->weight = weight;
		root->left = NULL;
		root->right = NULL;
		return root;
	}

	if (root->weight < weight) {
		return insertNode(root->right, value, weight);
	} else {
		return insertNode(root->left, value, weight);
	}
}

void readBinaryTree(nodeT * &r, ifstream &input, nodeT* &answ) {
	int n;
	input >> n;
	int w, v;
	for (int i=0; i<n; i++) {
		input >> v >> w;
		nodeT * node = insertNode(r, v, w);
		if (w % 10 == 1) {
			answ = node;
		}
	}
}

void readTreeTest(nodeT * &root, nodeT * &answ, int testNum) {
	string testFileName = string("duplicate1\\test") + integerToString(testNum) + ".txt";
	root = NULL;
	ifstream input;
	input.open(testFileName.c_str());
	readBinaryTree(root, input, answ);
	clearWeights(root);
	input.close();
}


void testDuplicate() {
	cout << "### Testing Duplicate Tree ###" << endl;
	int testNum = 0;
	int passed = 0;

	nodeT * root;
	nodeT * res;
	nodeT * answ;
	for (int i=1; i<=10; i++) {
		answ = NULL;
		readTreeTest(root, answ, i);
		res = bigestDuplicate(root);
		bool isCorrect = res == answ;
		printTestResults(isCorrect, testNum, passed);
	}

	cout << "passed: " << passed << endl;
}

void testBigInteger() {
	cout << "### Testing Big Integer ###" << endl;
	int testNum = 0;
	int passed = 0;
	bool isCorrect;
	BigInteger * n;
	BigInteger * m;
	//#1
	n = new BigInteger();
	isCorrect = n->toString() == "0";
	printTestResults(isCorrect, testNum, passed);
	//#2
	n = new BigInteger();
	n->setValue("12225678910");
	isCorrect = n->toString() == "12225678910";
	n->setValue("1232");
	isCorrect = isCorrect && n->toString() == "1232";
	printTestResults(isCorrect, testNum, passed);
	//#3
	n = new BigInteger();
	n->setValue("12345678910");
	n->setValue("0");
	n->setValue("189371928739128739127937129387128937128973981273912123123123187");
	isCorrect = n->toString() == "189371928739128739127937129387128937128973981273912123123123187";
	printTestResults(isCorrect, testNum, passed);
	//#4
	n = new BigInteger();
	n->setValue("34");
	n->insertDigit(0, 1);
	n->insertDigit(5, 0);
	isCorrect = n->toString() == "5304";
	printTestResults(isCorrect, testNum, passed);
	//#5
	n = new BigInteger();
	n->setValue("78");
	n->insertDigit(0, 1);
	n->insertDigit(5, 0);
	n->insertDigit(4, 4);
	isCorrect = n->toString() == "57084";
	printTestResults(isCorrect, testNum, passed);
	//#6
	n = new BigInteger();
	n->insertDigit(1, 0);
	n->insertDigit(4, 0);
	n->insertDigit(2, 3);
	isCorrect = n->toString() == "4102";
	printTestResults(isCorrect, testNum, passed);
	//#7
	n = new BigInteger();
	n->setValue("1234");
	n->removeDigit(0);
	n->removeDigit(0);
	n->removeDigit(0);
	isCorrect = n->toString() == "4";
	printTestResults(isCorrect, testNum, passed);
	//#8
	n = new BigInteger();
	n->setValue("1934");
	n->removeDigit(3);
	n->removeDigit(0);
	n->removeDigit(1);
	isCorrect = n->toString() == "9";
	printTestResults(isCorrect, testNum, passed);
	//#9
	n = new BigInteger();
	n->setValue("1289");
	n->removeDigit(3);
	n->removeDigit(1);
	n->insertDigit(4, 2);//184
	n->removeDigit(0);
	isCorrect = n->toString() == "84";
	printTestResults(isCorrect, testNum, passed);
	//#10
	n = new BigInteger();
	n->setValue("5");
	m = new BigInteger();
	m->setValue("8");
	n->add(*m);
	isCorrect = n->toString() == "13" && 
				m->toString() == "8";
	printTestResults(isCorrect, testNum, passed);
	//#11
	n = new BigInteger();
	n->setValue("9999");
	m = new BigInteger();
	m->setValue("1");
	n->add(*m);
	isCorrect = n->toString() == "10000" && 
				m->toString() == "1";
	printTestResults(isCorrect, testNum, passed);
	//#12
	n = new BigInteger();
	n->setValue("876381226387126381260");
	m = new BigInteger();
	m->setValue("91827398127398712937129379217397921837981273921783910");
	n->add(*m);
	isCorrect = n->toString() == "91827398127398712937129379217398798219207661048165170" && 
				m->toString() == "91827398127398712937129379217397921837981273921783910";
	printTestResults(isCorrect, testNum, passed);
	//#13
	n = new BigInteger();
	n->setValue("9999999999999999999999999999999999999999999990");
	m = new BigInteger();
	m->setValue("20");
	n->add(*m);
	isCorrect = n->toString() == "10000000000000000000000000000000000000000000010" && 
				m->toString() == "20";
	printTestResults(isCorrect, testNum, passed);
	//#14
	n = new BigInteger();
	n->setValue("9999999999999999999999999999999999999999999990");
	m = new BigInteger();
	m->setValue("20");
	n->add(*m);
	n->add(*m);
	n->add(*m);
	isCorrect = n->toString() == "10000000000000000000000000000000000000000000050" && 
				m->toString() == "20";
	printTestResults(isCorrect, testNum, passed);
	//#15
	n = new BigInteger();
	n->setValue("9999999999999999999999999999999999999999999990");
	m = new BigInteger();
	m->setValue("20");
	n->add(*m);
	n->add(*m);
	n->add(*m);
	m->setValue("50");
	m->add(*n);
	isCorrect = n->toString() == "10000000000000000000000000000000000000000000050" && 
				m->toString() == "10000000000000000000000000000000000000000000100";
	printTestResults(isCorrect, testNum, passed);

	cout << "passed: " << passed << endl;	
}

int main() {
	setRandomSeed(0);
	testDuplicate();
	testBigInteger();
	return 0;
}