#include <string>

using namespace std;


class BigInteger {
public:	
	BigInteger();
	~BigInteger();
	void setValue(string num);
	string toString();
	void add(BigInteger &num);
	void insertDigit(int digit, int pos);
	void removeDigit(int pos);

private:

};