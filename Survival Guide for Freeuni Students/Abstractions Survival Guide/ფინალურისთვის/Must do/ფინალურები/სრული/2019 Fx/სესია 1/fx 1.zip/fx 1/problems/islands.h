#include <string>
#include "grid.h"


using namespace std;


int numIslands(Grid<int> &g);