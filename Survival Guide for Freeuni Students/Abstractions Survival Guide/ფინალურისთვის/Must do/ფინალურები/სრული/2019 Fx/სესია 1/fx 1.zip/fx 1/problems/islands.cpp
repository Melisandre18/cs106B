#include "islands.h"

int numIslands(Grid<int> &g) {
	return -1;
}
