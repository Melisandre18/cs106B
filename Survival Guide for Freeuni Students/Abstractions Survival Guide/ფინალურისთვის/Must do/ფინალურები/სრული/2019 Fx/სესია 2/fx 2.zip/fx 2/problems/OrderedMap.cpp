#include "OrderedMap.h"

OrderedMap::OrderedMap() {
}

void OrderedMap::put(string key, int value) {
}

bool OrderedMap::containsKey(string key) {
	return false;
}

int OrderedMap::get(string key) {
	return -1;
}

void OrderedMap::remove(string key) {
}

int OrderedMap::size() {
	return -1;
}
