#include "longest_path.h"
#include "strlib.h"

int getLongestPath(Node * root) {
	return -1;
}

