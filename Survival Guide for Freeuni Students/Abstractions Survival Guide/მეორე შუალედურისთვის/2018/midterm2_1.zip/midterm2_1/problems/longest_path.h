#include "common.h"
#include <cstdio>

using namespace std;

int getLongestPath(Node * root);

