#include "my_string.h"

MyString::MyString() {
}
MyString::~MyString() {

}

int MyString::length() {
	return -1;
}

void MyString::insert(int pos, char c) {
}

char MyString::get(int indx) {
	return -1;
}

void MyString::set(int pos, char c) {
}

MyString * MyString::substr(int start, int len) {
	return NULL;
}

int MyString::find(MyString * s) {
	return -1;
}
