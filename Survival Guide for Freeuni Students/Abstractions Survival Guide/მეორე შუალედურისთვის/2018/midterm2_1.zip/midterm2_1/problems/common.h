#ifndef COMMON_INCL
#define COMMON_INCL
#include <string>
struct Node {
	int v;
	Node * left;
	Node * right;
};

#endif