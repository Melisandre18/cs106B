#include <string>

using namespace std;

class PrQueue {
public:
	PrQueue();
	void enqueue(int k, int pr);
	int dequeue();
	int peek();
	int size();
	void resetIterator();
	bool hasNext();
	void next(int &next, int &pr);
private:
	struct cell{
		int val;
		int pr;
		cell* next;
	};
	cell* it;
	cell* cl;
	cell* head;
	int len;
};