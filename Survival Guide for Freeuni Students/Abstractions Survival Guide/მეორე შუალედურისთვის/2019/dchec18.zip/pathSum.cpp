#include "pathSum.h"


using namespace std;


void pathSum(nodeT * root, int s, Set<nodeT *> &nodes) {
	if(root == NULL) return;
	if(root->left == NULL && root->right == NULL){
		if(!(s - root->v)) nodes.add(root);
		return;
	}else{
		pathSum(root->left, s - root->v , nodes);
		pathSum(root ->right,s - root->v , nodes);
	}
}